<?php
// admin/license-edit.php — edit issued_to / site_domain / notes
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/log.php';

require_admin();
require_perm('manage_licenses');

// ---- DB handle
$dbc = null;
if (isset($db) && $db instanceof mysqli)             { $dbc = $db; }
elseif (isset($conn) && $conn instanceof mysqli)     { $dbc = $conn; }
elseif (isset($mysqli) && $mysqli instanceof mysqli) { $dbc = $mysqli; }
elseif (function_exists('get_db'))                   { $dbc = get_db(); }
if (!$dbc instanceof mysqli) { http_response_code(500); exit('Database handle not initialized.'); }

// ensure table shape (same as other license pages)
$dbc->query("CREATE TABLE IF NOT EXISTS licenses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  license_key VARCHAR(64) NOT NULL UNIQUE,
  status VARCHAR(20) NOT NULL DEFAULT 'issued',      -- issued|active|revoked|expired
  type VARCHAR(20) NOT NULL DEFAULT 'full',          -- full|demo
  issued_to VARCHAR(190) NULL,
  site_domain VARCHAR(190) NULL,
  expires_at DATETIME NULL,
  activated_at DATETIME NULL,
  notes TEXT NULL,
  created_by VARCHAR(128) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

@ $dbc->query("ALTER TABLE licenses MODIFY COLUMN status VARCHAR(20) NOT NULL DEFAULT 'issued'");
@ $dbc->query("ALTER TABLE licenses MODIFY COLUMN type VARCHAR(20) NOT NULL DEFAULT 'full'");

// CSRF
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
$csrf = $_SESSION['csrf'];

// id
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) { http_response_code(400); exit('Missing id.'); }

// load current
$stmt = $dbc->prepare("SELECT id, license_key, status, type, issued_to, site_domain, notes, expires_at, activated_at FROM licenses WHERE id=?");
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
$lic = $res ? $res->fetch_assoc() : null;
$stmt->close();
if (!$lic) { http_response_code(404); exit('License not found.'); }

$error = '';
$done  = false;

// on submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
    http_response_code(400); exit('Bad CSRF token.');
  }

  $issued_to  = trim((string)($_POST['issued_to'] ?? ''));
  $site_domain= trim((string)($_POST['site_domain'] ?? ''));
  $notes      = trim((string)($_POST['notes'] ?? ''));

  // light normalization on domain (remove scheme + trailing slash)
  if ($site_domain !== '') {
    $site_domain = preg_replace('#^https?://#i', '', $site_domain);
    $site_domain = rtrim($site_domain, "/");
  }

  // build changed-fields summary for audit
  $changes = [];
  if ($issued_to !== (string)$lic['issued_to'])     $changes[] = 'issued_to';
  if ($site_domain !== (string)$lic['site_domain']) $changes[] = 'site_domain';
  if ($notes !== (string)$lic['notes'])             $changes[] = 'notes';

  if (empty($changes)) {
    header('Location: licenses.php'); exit;
  }

  if ($stmt = $dbc->prepare("UPDATE licenses SET issued_to=?, site_domain=?, notes=?, updated_at=NOW() WHERE id=?")) {
    $stmt->bind_param('sssi', $issued_to, $site_domain, $notes, $id);
    $ok = $stmt->execute(); $stmt->close();
    if ($ok) {
      $masked_to  = $issued_to !== '' ? log_mask($issued_to) : '(empty)';
      $masked_dom = $site_domain !== '' ? $site_domain : '(empty)';
      $chg = implode(',', $changes);
      log_audit('license_edited', "id={$id}; key=".log_mask($lic['license_key'])."; changed={$chg}; to={$masked_to}; domain={$masked_dom}", 'admin');
      $done = true;
    } else {
      $error = 'Update failed.';
    }
  } else {
    $error = 'DB error preparing update.';
  }
}

// header loader
$loadedHeader = false;
foreach ([__DIR__.'/admin-header.php', __DIR__.'/header-admin.php', __DIR__.'/header.php', __DIR__.'/../includes/admin-header.php'] as $p) {
  if (is_file($p)) { include $p; $loadedHeader = true; break; }
}
if (!$loadedHeader) {
  echo "<!doctype html><html><head><meta charset='utf-8'><title>Edit License</title>
  <style>body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif}</style>
  </head><body>";
}
?>
<h1>Edit License</h1>

<style>
.box{border:1px solid #ddd;border-radius:8px;padding:12px;background:#fff;max-width:760px}
.form-row{margin:.5rem 0}
label{display:block;margin-bottom:.25rem}
input[type=text],textarea{width:100%;max-width:560px}
.key{font-family:ui-monospace,Menlo,Consolas,monospace}
.badge{padding:.15rem .4rem;border-radius:.3rem;border:1px solid #ccc;font-size:.85rem}
.badge.ok{background:#e8fff0;border-color:#9bd3af}
.note{font-size:.9rem;color:#555}
</style>

<?php if ($done): ?>
  <div class="box">
    <h3>✅ License updated</h3>
    <p><strong>Key:</strong> <span class="key"><?= htmlspecialchars($lic['license_key']) ?></span></p>
    <p style="margin-top:.6rem;">
      <a class="badge ok" href="licenses.php">Back to Licenses</a>
    </p>
  </div>
<?php else: ?>
  <?php if ($error): ?><div style="color:#b00; margin:.5rem 0;"><?= htmlspecialchars($error) ?></div><?php endif; ?>

  <div class="box">
    <p><strong>Key:</strong> <span class="key"><?= htmlspecialchars($lic['license_key']) ?></span></p>
    <p><strong>Status:</strong> <?= htmlspecialchars($lic['status']) ?> · <strong>Type:</strong> <?= htmlspecialchars($lic['type']) ?></p>
    <form method="post" style="margin-top:.5rem;">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">

      <div class="form-row">
        <label>Issued to (name or email)</label>
        <input type="text" name="issued_to" value="<?= htmlspecialchars((string)$lic['issued_to']) ?>" placeholder="e.g., Jane Doe or jane@example.com">
      </div>

      <div class="form-row">
        <label>Site domain</label>
        <input type="text" name="site_domain" value="<?= htmlspecialchars((string)$lic['site_domain']) ?>" placeholder="league.example.com (no http://)">
        <div class="note">We store just the host (no protocol). Example: <code>league.example.com</code></div>
      </div>

      <div class="form-row">
        <label>Notes</label>
        <textarea name="notes" rows="5" placeholder="Any internal notes"><?= htmlspecialchars((string)$lic['notes']) ?></textarea>
      </div>

      <div class="form-row" style="margin-top:.6rem;">
        <button type="submit">Save Changes</button>
        <a href="licenses.php" style="margin-left:.5rem;">Cancel</a>
      </div>
    </form>
  </div>
<?php endif; ?>

<?php if (!$loadedHeader) { echo "</body></html>"; } ?>
