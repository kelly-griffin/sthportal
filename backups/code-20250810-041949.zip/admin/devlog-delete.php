<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/log.php';

require_admin();

// DB handle
$dbc = null;
if (isset($db) && $db instanceof mysqli)             { $dbc = $db; }
elseif (isset($conn) && $conn instanceof mysqli)     { $dbc = $conn; }
elseif (isset($mysqli) && $mysqli instanceof mysqli) { $dbc = $mysqli; }
elseif (function_exists('get_db'))                   { $dbc = get_db(); }
if (!$dbc instanceof mysqli) { http_response_code(500); exit('Database handle not initialized.'); }

// ensure table
$dbc->query("CREATE TABLE IF NOT EXISTS devlog (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  body MEDIUMTEXT NOT NULL,
  tags VARCHAR(200) NULL,
  created_by VARCHAR(128) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

// CSRF
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
$csrf = $_SESSION['csrf'];

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) { http_response_code(400); exit('Missing id.'); }

// load entry
$stmt = $dbc->prepare("SELECT id, title FROM devlog WHERE id=?");
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
$entry = $res ? $res->fetch_assoc() : null;
$stmt->close();
if (!$entry) { http_response_code(404); exit('Entry not found.'); }

// perform delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
    http_response_code(400); exit('Bad CSRF token.');
  }
  if ($stmt = $dbc->prepare("DELETE FROM devlog WHERE id=?")) {
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
  }
  log_audit('devlog_deleted', "id={$id}; title=".log_mask($entry['title']), 'admin');
  header('Location: devlog.php'); exit;
}

// header loader
$loadedHeader = false;
foreach ([__DIR__.'/admin-header.php', __DIR__.'/header-admin.php', __DIR__.'/header.php', __DIR__.'/../includes/admin-header.php'] as $p) {
  if (is_file($p)) { include $p; $loadedHeader = true; break; }
}
if (!$loadedHeader) {
  echo "<!doctype html><html><head><meta charset='utf-8'><title>Delete Devlog Entry</title></head><body>";
}
?>
<h1>Delete Devlog Entry</h1>

<p>Are you sure you want to delete this entry?</p>
<ul>
  <li><strong>Title:</strong> <?= htmlspecialchars($entry['title']) ?></li>
</ul>

<form method="post" style="margin-top:.5rem;">
  <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
  <button type="submit" style="color:#b00">Yes, delete</button>
  <a href="devlog.php" style="margin-left:.5rem;">Cancel</a>
</form>

<?php if (!$loadedHeader) { echo "</body></html>"; } ?>
