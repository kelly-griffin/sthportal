<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

require_admin(); // no license required to review attempts

// normalize DB handle
$dbc = null;
if (isset($db) && $db instanceof mysqli)             { $dbc = $db; }
elseif (isset($conn) && $conn instanceof mysqli)     { $dbc = $conn; }
elseif (isset($mysqli) && $mysqli instanceof mysqli) { $dbc = $mysqli; }
elseif (function_exists('get_db'))                   { $dbc = get_db(); }
if (!$dbc instanceof mysqli) { http_response_code(500); exit('DB not initialized'); }

// fetch latest attempts
$res = $dbc->query("SELECT id, actor, ip, success, note, created_at
                      FROM login_attempts
                  ORDER BY id DESC
                     LIMIT 200");

// header loader
$loadedHeader = false;
foreach ([__DIR__.'/admin-header.php', __DIR__.'/header-admin.php', __DIR__.'/header.php', __DIR__.'/../includes/admin-header.php'] as $p) {
  if (is_file($p)) { include $p; $loadedHeader = true; break; }
}
if (!$loadedHeader) {
  echo "<!doctype html><html><head><meta charset='utf-8'><title>Login Attempts</title></head><body>";
}
?>
<h1>Login Attempts</h1>
<style>
.table{border-collapse:collapse;width:100%}
.table th,.table td{border:1px solid #ddd;padding:6px 8px}
.table th{background:#f7f7f7;text-align:left}
.badge{padding:.15rem .4rem;border-radius:.3rem;border:1px solid #ccc;font-size:.85rem}
.badge.ok{background:#e8fff0;border-color:#9bd3af}
.badge.fail{background:#ffecec;border-color:#e3a0a0}
.empty{padding:10px;border:1px dashed #ccc;background:#fafafa}
</style>

<?php if (!$res || $res->num_rows === 0): ?>
  <div class="empty">No login attempts yet.</div>
<?php else: ?>
  <table class="table">
    <tr>
      <th>ID</th><th>Actor</th><th>IP</th><th>Success</th><th>Note</th><th>When</th>
    </tr>
    <?php while ($row = $res->fetch_assoc()): ?>
      <tr>
        <td><?= (int)$row['id'] ?></td>
        <td><?= htmlspecialchars((string)$row['actor']) ?></td>
        <td><?= htmlspecialchars((string)$row['ip']) ?></td>
        <td>
          <?php $ok = (int)$row['success'] === 1; ?>
          <span class="badge <?= $ok ? 'ok' : 'fail' ?>"><?= $ok ? 'yes' : 'no' ?></span>
        </td>
        <td><?= htmlspecialchars((string)$row['note']) ?></td>
        <td><?= htmlspecialchars((string)$row['created_at']) ?></td>
      </tr>
    <?php endwhile; ?>
  </table>
<?php endif; ?>

<?php if (!$loadedHeader) { echo "</body></html>"; } ?>
