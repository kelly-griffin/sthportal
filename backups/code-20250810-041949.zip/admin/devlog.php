<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/log.php';

require_admin();

// DB handle
$dbc = null;
if (isset($db) && $db instanceof mysqli)             { $dbc = $db; }
elseif (isset($conn) && $conn instanceof mysqli)     { $dbc = $conn; }
elseif (isset($mysqli) && $mysqli instanceof mysqli) { $dbc = $mysqli; }
elseif (function_exists('get_db'))                   { $dbc = get_db(); }
if (!$dbc instanceof mysqli) { http_response_code(500); exit('Database handle not initialized.'); }

// ensure table
$dbc->query("CREATE TABLE IF NOT EXISTS devlog (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  body MEDIUMTEXT NOT NULL,
  tags VARCHAR(200) NULL,
  created_by VARCHAR(128) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

// fetch latest 200
$res = $dbc->query("SELECT id, title, tags, created_by, created_at, updated_at
                      FROM devlog
                  ORDER BY id DESC
                     LIMIT 200");

// header loader
$loadedHeader = false;
foreach ([__DIR__.'/admin-header.php', __DIR__.'/header-admin.php', __DIR__.'/header.php', __DIR__.'/../includes/admin-header.php'] as $p) {
  if (is_file($p)) { include $p; $loadedHeader = true; break; }
}
if (!$loadedHeader) {
  echo <<<'HTML'
<!doctype html><html><head><meta charset="utf-8"><title>Devlog</title>
<style>
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif}
.adminbar{display:flex;gap:12px;align-items:center;padding:10px;border-bottom:1px solid #ddd;background:#f7f7f7}
.adminbar a{color:#333;text-decoration:none}.adminbar a:hover{text-decoration:underline}
</style>
</head><body>
<nav class="adminbar">
  <a href="index.php">↩️ Admin Home</a>
  <a href="logout.php">🚪 Logout</a>
</nav>
HTML;
}
?>
<h1>Devlog</h1>

<p><a href="devlog-edit.php?new=1">➕ New Entry</a></p>

<style>
.table{border-collapse:collapse;width:100%}
.table th,.table td{border:1px solid #ddd;padding:6px 8px;font-size:.95rem}
.table th{background:#f7f7f7;text-align:left}
.badge{padding:.15rem .4rem;border-radius:.3rem;border:1px solid #ccc;font-size:.85rem}
.empty{padding:10px;border:1px dashed #ccc;background:#fafafa}
.tags{color:#555;font-size:.9rem}
.actions a{margin-right:.5rem}
</style>

<?php if (!$res || $res->num_rows === 0): ?>
  <div class="empty">No entries yet. Click <a href="devlog-edit.php?new=1">New Entry</a> to add one.</div>
<?php else: ?>
  <table class="table">
    <tr>
      <th>ID</th><th>Title</th><th>Tags</th><th>Author</th><th>Created</th><th>Updated</th><th>Actions</th>
    </tr>
    <?php while ($r = $res->fetch_assoc()): ?>
      <tr>
        <td><?= (int)$r['id'] ?></td>
        <td><?= htmlspecialchars($r['title']) ?></td>
        <td class="tags"><?= htmlspecialchars((string)$r['tags']) ?></td>
        <td><?= htmlspecialchars((string)$r['created_by']) ?></td>
        <td><?= htmlspecialchars((string)$r['created_at']) ?></td>
        <td><?= htmlspecialchars((string)$r['updated_at']) ?></td>
        <td class="actions">
          <a href="devlog-edit.php?id=<?= (int)$r['id'] ?>">Edit</a>
          <a href="devlog-delete.php?id=<?= (int)$r['id'] ?>">Delete</a>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>
<?php endif; ?>

<?php if (!$loadedHeader) { echo "</body></html>"; } ?>
