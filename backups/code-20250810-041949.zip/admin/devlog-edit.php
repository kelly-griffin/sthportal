<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/log.php';

require_admin();

// DB handle
$dbc = null;
if (isset($db) && $db instanceof mysqli)             { $dbc = $db; }
elseif (isset($conn) && $conn instanceof mysqli)     { $dbc = $conn; }
elseif (isset($mysqli) && $mysqli instanceof mysqli) { $dbc = $mysqli; }
elseif (function_exists('get_db'))                   { $dbc = get_db(); }
if (!$dbc instanceof mysqli) { http_response_code(500); exit('Database handle not initialized.'); }

// ensure table
$dbc->query("CREATE TABLE IF NOT EXISTS devlog (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  body MEDIUMTEXT NOT NULL,
  tags VARCHAR(200) NULL,
  created_by VARCHAR(128) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

// CSRF
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
$csrf = $_SESSION['csrf'];

// edit vs new
$isNew = isset($_GET['new']) || (($_GET['id'] ?? '') === '');
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$error = '';
$entry = ['title'=>'', 'body'=>'', 'tags'=>''];

// load
if (!$isNew) {
  $stmt = $dbc->prepare("SELECT id, title, body, tags FROM devlog WHERE id=?");
  $stmt->bind_param('i', $id);
  $stmt->execute();
  $res = $stmt->get_result();
  if ($res && $res->num_rows) { $entry = $res->fetch_assoc(); }
  else { http_response_code(404); exit('Entry not found.'); }
  $stmt->close();
}

// save
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
    http_response_code(400); exit('Bad CSRF token.');
  }

  $title = trim((string)($_POST['title'] ?? ''));
  $body  = trim((string)($_POST['body'] ?? ''));
  $tags  = trim((string)($_POST['tags'] ?? ''));

  if ($title === '') $error = 'Title is required.';
  elseif ($body === '') $error = 'Body is required.';

  if ($error === '') {
    $now = (new DateTimeImmutable('now'))->format('Y-m-d H:i:s');
    $author = $_SESSION['admin_name'] ?? 'admin';

    if ($isNew) {
      if ($stmt = $dbc->prepare("INSERT INTO devlog (title, body, tags, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)")) {
        $stmt->bind_param('ssssss', $title, $body, $tags, $author, $now, $now);
        $ok = $stmt->execute(); $newId = $stmt->insert_id; $stmt->close();
        if ($ok) {
          log_audit('devlog_created', "id={$newId}; title=".log_mask($title), 'admin');
          header('Location: devlog.php'); exit;
        } else { $error = 'Insert failed.'; }
      } else { $error = 'DB error preparing insert.'; }
    } else {
      if ($stmt = $dbc->prepare("UPDATE devlog SET title=?, body=?, tags=?, updated_at=? WHERE id=?")) {
        $stmt->bind_param('ssssi', $title, $body, $tags, $now, $id);
        $ok = $stmt->execute(); $stmt->close();
        if ($ok) {
          log_audit('devlog_updated', "id={$id}; title=".log_mask($title), 'admin');
          header('Location: devlog.php'); exit;
        } else { $error = 'Update failed.'; }
      } else { $error = 'DB error preparing update.'; }
    }
  }

  // repopulate on error
  $entry = ['title'=>$title, 'body'=>$body, 'tags'=>$tags];
}

// header loader
$loadedHeader = false;
foreach ([__DIR__.'/admin-header.php', __DIR__.'/header-admin.php', __DIR__.'/header.php', __DIR__.'/../includes/admin-header.php'] as $p) {
  if (is_file($p)) { include $p; $loadedHeader = true; break; }
}
if (!$loadedHeader) {
  echo "<!doctype html><html><head><meta charset='utf-8'><title>".($isNew?'New':'Edit')." Devlog</title></head><body>";
}
?>
<h1><?= $isNew ? 'New Devlog Entry' : 'Edit Devlog Entry' ?></h1>
<?php if ($error): ?><div style="color:#b00; margin:.5rem 0;"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<form method="post">
  <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
  <div style="margin:.4rem 0;">
    <label style="display:block;margin-bottom:.25rem;">Title</label>
    <input type="text" name="title" value="<?= htmlspecialchars($entry['title']) ?>" required style="width:100%;">
  </div>
  <div style="margin:.4rem 0;">
    <label style="display:block;margin-bottom:.25rem;">Tags (comma-separated)</label>
    <input type="text" name="tags" value="<?= htmlspecialchars($entry['tags']) ?>" placeholder="auth, schema, deploy" style="width:100%;">
  </div>
  <div style="margin:.4rem 0;">
    <label style="display:block;margin-bottom:.25rem;">Body</label>
    <textarea name="body" rows="14" required style="width:100%;font-family:ui-monospace,Menlo,Consolas,monospace;"><?= htmlspecialchars($entry['body']) ?></textarea>
  </div>

  <div style="margin-top:.6rem;">
    <button type="submit"><?= $isNew ? 'Create Entry' : 'Save Changes' ?></button>
    <a href="devlog.php" style="margin-left:.5rem;">Cancel</a>
  </div>
</form>

<?php if (!$loadedHeader) { echo "</body></html>"; } ?>
