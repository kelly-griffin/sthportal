<?php
// admin/admin-header.php — shared admin top bar
// Renders only the bar (no full HTML), so pages can print their own <h1> etc.

if (!defined('ADMIN_HEADER_RENDERED')) {
    define('ADMIN_HEADER_RENDERED', 1);

    // Pull SITE_URL if set; fall back to a safe default
    @require_once __DIR__ . '/../includes/config.php';

    $siteUrl = defined('SITE_URL') ? (string)SITE_URL : '/index.php';
    // Normalize: if they gave us a bare domain, ensure it ends with /index.php
    $parsed = parse_url($siteUrl);
    $path   = isset($parsed['path']) ? $parsed['path'] : '';
    if ($path === '' || substr($path, -1) === '/') {
        $siteUrl = rtrim($siteUrl, '/') . '/index.php';
    }

    $adminHome = 'index.php';
    $logoutUrl = 'logout.php';
    ?>
    <style>
      .adminbar{
        display:flex; gap:12px; align-items:center;
        padding:10px; border-bottom:1px solid #ddd; background:#f7f7f7;
        font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif
      }
      .adminbar a{ color:#333; text-decoration:none; }
      .adminbar a:hover{ text-decoration:underline; }
      .adminbar .sep{ color:#999; }
    </style>
    <nav class="adminbar">
      <a href="<?= htmlspecialchars($adminHome) ?>">🏠 Admin Home</a>
      <span class="sep">|</span>
      <a href="<?= htmlspecialchars($siteUrl) ?>">↩️ Back to Site</a>
      <span class="sep">|</span>
      <a href="<?= htmlspecialchars($logoutUrl) ?>">🚪 Logout</a>
    </nav>
    <?php
}
