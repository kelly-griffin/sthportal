<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/log.php';
require_once __DIR__ . '/../includes/user-auth.php';

require_admin();

// ---- normalize DB handle
$dbc = null;
if (isset($db) && $db instanceof mysqli)             { $dbc = $db; }
elseif (isset($conn) && $conn instanceof mysqli)     { $dbc = $conn; }
elseif (isset($mysqli) && $mysqli instanceof mysqli) { $dbc = $mysqli; }
elseif (function_exists('get_db'))                   { $dbc = get_db(); }
if (!$dbc instanceof mysqli) { http_response_code(500); exit('Database handle not initialized.'); }

// must be licensed & permitted
require_license($dbc);
require_perm('manage_users');

// ensure schema has lockout fields
ua_ensure_users($dbc);

// fetch latest 500 (include lockout + last login)
$res = $dbc->query("SELECT id, name, email, role, active, last_login_at, failed_logins, locked_until, created_at, updated_at
                      FROM users
                  ORDER BY id DESC
                     LIMIT 500");

// ---- header loader
$loadedHeader = false;
foreach ([__DIR__.'/admin-header.php', __DIR__.'/header-admin.php', __DIR__.'/header.php', __DIR__.'/../includes/admin-header.php'] as $p) {
  if (is_file($p)) { include $p; $loadedHeader = true; break; }
}
if (!$loadedHeader) {
  echo <<<'HTML'
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Users</title>
  <style>
    .adminbar{display:flex;gap:12px;align-items:center;padding:10px;border-bottom:1px solid #ddd;background:#f7f7f7}
    .adminbar a{color:#333;text-decoration:none}.adminbar a:hover{text-decoration:underline}
    body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif}
  </style>
</head>
<body>
  <nav class="adminbar">
    <a href="index.php">↩️ Back to Admin Home</a>
    <a href="logout.php">🚪 Logout</a>
  </nav>
HTML;
}
?>
<h1>Users</h1>

<p><a href="user-edit.php?new=1">➕ Add User</a></p>

<style>
.table{border-collapse:collapse;width:100%;max-width:100%}
.table th,.table td{border:1px solid #ddd;padding:6px 8px;font-size:.95rem}
.table th{background:#f7f7f7;text-align:left}
.badge{padding:.15rem .4rem;border-radius:.3rem;border:1px solid #ccc;font-size:.85rem}
.badge.ok{background:#e8fff0;border-color:#9bd3af}
.badge.off{background:#f5f5f5;color:#666}
.badge.warn{background:#fff6e5;border-color:#f1c27d}
.badge.lock{background:#ffecec;border-color:#e3a0a0}
.actions a{margin-right:.5rem}
.empty{padding:10px;border:1px dashed #ccc;background:#fafafa}
</style>

<?php if (!$res || $res->num_rows === 0): ?>
  <div class="empty">No users yet. Click <a href="user-edit.php?new=1">Add User</a> to create one.</div>
<?php else: ?>
  <table class="table">
    <tr>
      <th>ID</th><th>Name</th><th>Email</th><th>Role</th>
      <th>Status</th><th>Last login</th><th>Failed</th><th>Lock</th><th>Actions</th>
    </tr>
    <?php
      $now = time();
      while ($u = $res->fetch_assoc()):
        $locked = !empty($u['locked_until']) && strtotime($u['locked_until']) > $now;
    ?>
      <tr>
        <td><?= (int)$u['id'] ?></td>
        <td><?= htmlspecialchars($u['name']) ?></td>
        <td><?= htmlspecialchars($u['email']) ?></td>
        <td><?= htmlspecialchars($u['role']) ?></td>
        <td>
          <?php $on = (int)$u['active'] === 1; ?>
          <span class="badge <?= $on ? 'ok' : 'off' ?>"><?= $on ? 'active' : 'inactive' ?></span>
        </td>
        <td><?= htmlspecialchars((string)$u['last_login_at']) ?></td>
        <td><span class="badge <?= ((int)$u['failed_logins']>0?'warn':'off') ?>"><?= (int)$u['failed_logins'] ?></span></td>
        <td>
          <?php if ($locked): ?>
            <span class="badge lock" title="locked until">
              locked until <?= htmlspecialchars((string)$u['locked_until']) ?>
            </span>
          <?php else: ?>
            <span class="badge off">unlocked</span>
          <?php endif; ?>
        </td>
        <td class="actions">
          <a href="user-edit.php?id=<?= (int)$u['id'] ?>">Edit</a>
          <a href="user-delete.php?id=<?= (int)$u['id'] ?>">Delete</a>
          <?php if ($locked): ?>
            <a href="user-unlock.php?id=<?= (int)$u['id'] ?>">Unlock</a>
          <?php endif; ?>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>
<?php endif; ?>

<?php if (!$loadedHeader) { echo "</body></html>"; } ?>
