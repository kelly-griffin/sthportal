<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/log.php';
require_once __DIR__ . '/../includes/user-auth.php';

require_admin();

// ---- DB handle
$dbc = null;
if (isset($db) && $db instanceof mysqli)             { $dbc = $db; }
elseif (isset($conn) && $conn instanceof mysqli)     { $dbc = $conn; }
elseif (isset($mysqli) && $mysqli instanceof mysqli) { $dbc = $mysqli; }
elseif (function_exists('get_db'))                   { $dbc = get_db(); }
if (!$dbc instanceof mysqli) { http_response_code(500); exit('Database handle not initialized.'); }

// license + permission
require_license($dbc);
require_perm('manage_users');

// ensure schema (users + columns)
ua_ensure_users($dbc);

// CSRF
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
$csrf = $_SESSION['csrf'];

$isNew = isset($_GET['new']) || (($_GET['id'] ?? '') === '');
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$error = '';
$user = ['name' => '', 'email' => '', 'role' => 'member', 'active' => 1];

// load existing
if (!$isNew) {
    $stmt = $dbc->prepare("SELECT id, name, email, role, active FROM users WHERE id=?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res && $res->num_rows) { $user = $res->fetch_assoc(); }
    else { http_response_code(404); exit('User not found.'); }
    $stmt->close();
}

// handle submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(400); exit('Bad CSRF token.');
    }

    $name   = trim((string)($_POST['name'] ?? ''));
    $email  = trim((string)($_POST['email'] ?? ''));
    $role   = trim((string)($_POST['role'] ?? 'member'));
    $active = !empty($_POST['active']) ? 1 : 0;

    $pwd    = (string)($_POST['password'] ?? '');
    $pwd2   = (string)($_POST['confirm'] ?? '');

    if ($name === '')        { $error = 'Name is required.'; }
    elseif ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) { $error = 'Valid email is required.'; }
    elseif (strlen($role) > 32) { $error = 'Role is too long.'; }
    elseif ($isNew && strlen($pwd) < 8) { $error = 'Password (min 8 chars) is required for new users.'; }
    elseif ($pwd !== '' && $pwd !== $pwd2) { $error = 'Passwords do not match.'; }

    if ($error === '') {
        $now = (new DateTimeImmutable('now'))->format('Y-m-d H:i:s');
        if ($isNew) {
            $hash = password_hash($pwd, PASSWORD_DEFAULT);
            if ($stmt = $dbc->prepare("INSERT INTO users (name, email, role, active, password_hash, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())")) {
                // FIXED: 5 values -> 'sssis'
                $stmt->bind_param('sssis', $name, $email, $role, $active, $hash);
                $ok = $stmt->execute();
                $stmt->close();
                if ($ok) {
                    log_audit('user_created', "name={$name}; email={$email}; role={$role}; active={$active}", 'admin');
                    header('Location: users.php'); exit;
                } else {
                    $error = $dbc->errno === 1062 ? 'Email already exists.' : 'Insert failed.';
                }
            } else { $error = 'DB error preparing insert.'; }
        } else {
            // update main fields
            if ($stmt = $dbc->prepare("UPDATE users SET name=?, email=?, role=?, active=?, updated_at=? WHERE id=?")) {
                $stmt->bind_param('sssisi', $name, $email, $role, $active, $now, $id);
                $ok = $stmt->execute();
                $stmt->close();
                if (!$ok) {
                    $error = $dbc->errno === 1062 ? 'Email already exists.' : 'Update failed.';
                }
            } else { $error = 'DB error preparing update.'; }

            // optional password change
            if ($error === '' && $pwd !== '') {
                $hash = password_hash($pwd, PASSWORD_DEFAULT);
                if ($stmt = $dbc->prepare("UPDATE users SET password_hash=?, failed_logins=0, locked_until=NULL, updated_at=? WHERE id=?")) {
                    $stmt->bind_param('ssi', $hash, $now, $id);
                    $stmt->execute();
                    $stmt->close();
                }
                log_audit('user_password_set', "id={$id}; email={$email}", 'admin');
            }

            if ($error === '') {
                log_audit('user_updated', "id={$id}; name={$name}; email={$email}; role={$role}; active={$active}", 'admin');
                header('Location: users.php'); exit;
            }
        }

        // refill on error
        $user = ['name' => $name, 'email' => $email, 'role' => $role, 'active' => $active];
    }
}

// header loader
$loadedHeader = false;
foreach ([__DIR__.'/admin-header.php', __DIR__.'/header-admin.php', __DIR__.'/header.php', __DIR__.'/../includes/admin-header.php'] as $p) {
  if (is_file($p)) { include $p; $loadedHeader = true; break; }
}
if (!$loadedHeader) {
  echo "<!doctype html><html><head><meta charset='utf-8'><title>".($isNew?'Add':'Edit')." User</title></head><body>";
}
?>
<h1><?= $isNew ? 'Add User' : 'Edit User' ?></h1>
<?php if ($error): ?><div style="color:#b00; margin:.5rem 0;"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<form method="post">
  <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
  <div style="margin:.4rem 0;">
    <label style="display:block;margin-bottom:.25rem;">Name</label>
    <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>
  </div>
  <div style="margin:.4rem 0;">
    <label style="display:block;margin-bottom:.25rem;">Email</label>
    <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
  </div>
  <div style="margin:.4rem 0;">
    <label style="display:block;margin-bottom:.25rem;">Role</label>
    <input type="text" name="role" value="<?= htmlspecialchars($user['role']) ?>" placeholder="member / admin etc.">
  </div>
  <div style="margin:.4rem 0;">
    <label><input type="checkbox" name="active" value="1" <?= (int)$user['active']===1?'checked':''; ?>> Active</label>
  </div>

  <fieldset style="border:1px solid #ddd;padding:.6rem;margin-top:.6rem;">
    <legend><?= $isNew ? 'Set Password' : 'Set/Change Password (optional)' ?></legend>
    <div style="margin:.4rem 0;">
      <label style="display:block;margin-bottom:.25rem;">Password</label>
      <input type="password" name="password" <?= $isNew?'required':''; ?> placeholder="min 8 chars">
    </div>
    <div style="margin:.4rem 0;">
      <label style="display:block;margin-bottom:.25rem;">Confirm</label>
      <input type="password" name="confirm" <?= $isNew?'required':''; ?>>
    </div>
  </fieldset>

  <div style="margin-top:.6rem;">
    <button type="submit"><?= $isNew ? 'Create' : 'Save Changes' ?></button>
    <a href="users.php" style="margin-left:.5rem;">Cancel</a>
  </div>
</form>

<?php if (!$loadedHeader) { echo "</body></html>"; } ?>
