<?php
// admin/licenses.php — list licenses + actions + SEARCH/FILTER (by key/email/domain, status, type)
// Self-heals old schemas where `status` enum caused empty values.
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/log.php';

require_admin();
require_perm('manage_licenses');

// ---- DB handle
$dbc = null;
if (isset($db) && $db instanceof mysqli)             { $dbc = $db; }
elseif (isset($conn) && $conn instanceof mysqli)     { $dbc = $conn; }
elseif (isset($mysqli) && $mysqli instanceof mysqli) { $dbc = $mysqli; }
elseif (function_exists('get_db'))                   { $dbc = get_db(); }
if (!$dbc instanceof mysqli) { http_response_code(500); exit('Database handle not initialized.'); }

// ---- ensure table shape
$dbc->query("CREATE TABLE IF NOT EXISTS licenses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  license_key VARCHAR(64) NOT NULL UNIQUE,
  status VARCHAR(20) NOT NULL DEFAULT 'issued',      -- issued|active|revoked|expired
  type VARCHAR(20) NOT NULL DEFAULT 'full',          -- full|demo
  issued_to VARCHAR(190) NULL,
  site_domain VARCHAR(190) NULL,
  expires_at DATETIME NULL,
  activated_at DATETIME NULL,
  notes TEXT NULL,
  created_by VARCHAR(128) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

@ $dbc->query("ALTER TABLE licenses ADD COLUMN IF NOT EXISTS license_key VARCHAR(64) NOT NULL UNIQUE");
@ $dbc->query("ALTER TABLE licenses ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'issued'");
@ $dbc->query("ALTER TABLE licenses ADD COLUMN IF NOT EXISTS type VARCHAR(20) NOT NULL DEFAULT 'full'");
@ $dbc->query("ALTER TABLE licenses ADD COLUMN IF NOT EXISTS issued_to VARCHAR(190) NULL");
@ $dbc->query("ALTER TABLE licenses ADD COLUMN IF NOT EXISTS site_domain VARCHAR(190) NULL");
@ $dbc->query("ALTER TABLE licenses ADD COLUMN IF NOT EXISTS expires_at DATETIME NULL");
@ $dbc->query("ALTER TABLE licenses ADD COLUMN IF NOT EXISTS activated_at DATETIME NULL");
@ $dbc->query("ALTER TABLE licenses ADD COLUMN IF NOT EXISTS notes TEXT NULL");
@ $dbc->query("ALTER TABLE licenses ADD COLUMN IF NOT EXISTS created_by VARCHAR(128) NULL");
@ $dbc->query("ALTER TABLE licenses ADD COLUMN IF NOT EXISTS updated_at DATETIME NULL");

@ $dbc->query("ALTER TABLE licenses MODIFY COLUMN status VARCHAR(20) NOT NULL DEFAULT 'issued'");
@ $dbc->query("ALTER TABLE licenses MODIFY COLUMN type VARCHAR(20) NOT NULL DEFAULT 'full'");

/* one-time cleanup for any blank statuses from enum mismatch */
@ $dbc->query("UPDATE licenses SET status='revoked', updated_at=NOW()
               WHERE (status='' OR status IS NULL) AND activated_at IS NOT NULL");
@ $dbc->query("UPDATE licenses SET status='expired', updated_at=NOW()
               WHERE (status='' OR status IS NULL) AND expires_at IS NOT NULL AND expires_at < NOW()");
@ $dbc->query("UPDATE licenses SET status='issued', updated_at=NOW()
               WHERE (status='' OR status IS NULL) AND (activated_at IS NULL) AND (expires_at IS NULL OR expires_at >= NOW())");

// ---- auto-expire sweep
$dbc->query("UPDATE licenses
                SET status='expired', updated_at=NOW()
              WHERE status IN ('active','issued')
                AND expires_at IS NOT NULL
                AND expires_at < NOW()");
$autoExpired = $dbc->affected_rows;

// ---- filters
$q       = trim((string)($_GET['q'] ?? ''));
$status  = strtolower(trim((string)($_GET['status'] ?? '')));
$type    = strtolower(trim((string)($_GET['type'] ?? '')));

$allowedStatus = ['','issued','active','revoked','expired'];
$allowedType   = ['','full','demo'];
if (!in_array($status, $allowedStatus, true)) { $status = ''; }
if (!in_array($type,   $allowedType,   true)) { $type   = ''; }

$where = [];
$typesBind = '';
$args  = [];

// status filter
if ($status !== '') { $where[] = 'status = ?'; $typesBind .= 's'; $args[] = $status; }
// type filter
if ($type !== '')   { $where[] = 'type = ?';   $typesBind .= 's'; $args[] = $type;   }

// keyword filter (license_key / issued_to (email/name) / site_domain)
if ($q !== '') {
    $where[] = '(license_key LIKE ? OR issued_to LIKE ? OR site_domain LIKE ?)';
    $kw = '%' . $q . '%';
    $typesBind .= 'sss';
    $args[] = $kw; $args[] = $kw; $args[] = $kw;
}

// ---- fetch
$sql = "SELECT id, license_key, status, type, issued_to, site_domain,
               expires_at, activated_at, created_by, created_at, updated_at
          FROM licenses";
if ($where) { $sql .= ' WHERE ' . implode(' AND ', $where); }
$sql .= " ORDER BY id DESC LIMIT 200";

$res = null;
if ($where) {
    $stmt = $dbc->prepare($sql);
    if ($typesBind !== '') { $stmt->bind_param($typesBind, ...$args); }
    $stmt->execute();
    $res = $stmt->get_result();
} else {
    $res = $dbc->query($sql);
}

// ---- header
$loadedHeader = false;
foreach ([__DIR__.'/admin-header.php', __DIR__.'/header-admin.php', __DIR__.'/header.php', __DIR__.'/../includes/admin-header.php'] as $p) {
  if (is_file($p)) { include $p; $loadedHeader = true; break; }
}
if (!$loadedHeader) {
  echo <<<'HTML'
<!doctype html>
<html>
<head>
  <meta charset="utf-8"><title>Licenses</title>
  <style>
    body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif}
    .adminbar{display:flex;gap:12px;align-items:center;padding:10px;border-bottom:1px solid #ddd;background:#f7f7f7}
    .adminbar a{color:#333;text-decoration:none}.adminbar a:hover{text-decoration:underline}
  </style>
</head>
<body>
  <nav class="adminbar">
    <a href="index.php">↩️ Admin Home</a>
    <a href="logout.php">🚪 Logout</a>
  </nav>
HTML;
}
?>
<h1>Licenses</h1>

<?php if ($autoExpired > 0): ?>
  <div style="margin:.5rem 0;padding:.4rem .6rem;background:#fff6e5;border:1px solid #f1c27d;border-radius:6px;">
    Auto-marked <strong><?= (int)$autoExpired ?></strong> license(s) as expired.
  </div>
<?php endif; ?>

<p style="display:flex;gap:.6rem;flex-wrap:wrap;">
  <a href="license-issue.php" class="btn">➕ Issue License</a>
  <a href="license-activate.php" class="btn">🔑 Activate License</a>
</p>

<!-- Search / Filter -->
<style>
.table{border-collapse:collapse;width:100%}
.table th,.table td{border:1px solid #ddd;padding:6px 8px;font-size:.95rem}
.table th{background:#f7f7f7;text-align:left}
.badge{padding:.15rem .4rem;border-radius:.3rem;border:1px solid #ccc;font-size:.85rem;display:inline-block}
.badge.issued{background:#eef3ff;border-color:#a7b8f0}
.badge.active{background:#e8fff0;border-color:#9bd3af}
.badge.revoked{background:#ffecec;border-color:#e3a0a0}
.badge.expired{background:#f5f5f5;color:#666;border-color:#ddd}
.key{font-family:ui-monospace,Menlo,Consolas,monospace}
.small{font-size:.9rem;color:#555}
.empty{padding:10px;border:1px dashed #ccc;background:#fafafa}
.btn{padding:.25rem .5rem;border:1px solid #ccc;border-radius:6px;background:#fff;text-decoration:none;color:#333}
.btn:hover{background:#f7f7f7}
.actions a{margin-right:.4rem}
.filterbar{display:flex;gap:.5rem;align-items:flex-end;flex-wrap:wrap;margin:.5rem 0;padding:.5rem;border:1px solid #eee;border-radius:8px;background:#fafafa}
.filterbar label{font-size:.85rem;color:#555;display:block;margin-bottom:.15rem}
.filterbar input[type=text]{padding:.3rem .4rem;width:260px}
.filterbar select{padding:.3rem .4rem}
</style>

<form method="get" class="filterbar">
  <div>
    <label for="q">Search (key / email / domain)</label>
    <input type="text" id="q" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="e.g., ABCD-123 / user@site / league.com">
  </div>
  <div>
    <label for="status">Status</label>
    <select id="status" name="status">
      <?php
        $opts = ['' => 'All', 'issued'=>'Issued', 'active'=>'Active', 'revoked'=>'Revoked', 'expired'=>'Expired'];
        foreach ($opts as $val=>$label) {
            $sel = ($status===$val) ? 'selected' : '';
            echo "<option value=\"".htmlspecialchars($val)."\" $sel>".htmlspecialchars($label)."</option>";
        }
      ?>
    </select>
  </div>
  <div>
    <label for="type">Type</label>
    <select id="type" name="type">
      <?php
        $tops = ['' => 'All', 'full'=>'Full', 'demo'=>'Demo'];
        foreach ($tops as $val=>$label) {
            $sel = ($type===$val) ? 'selected' : '';
            echo "<option value=\"".htmlspecialchars($val)."\" $sel>".htmlspecialchars($label)."</option>";
        }
      ?>
    </select>
  </div>
  <div>
    <button type="submit" class="btn">Filter</button>
    <?php if ($q !== '' || $status !== '' || $type !== ''): ?>
      <a class="btn" href="licenses.php">Clear</a>
    <?php endif; ?>
  </div>
</form>

<?php
$total = ($res && method_exists($res, 'num_rows')) ? (int)$res->num_rows : 0;
if ($q !== '' || $status !== '' || $type !== '') {
  echo '<div class="small" style="margin:.25rem 0;">Showing '. $total .' result(s)</div>';
}
?>

<?php if (!$res || $res->num_rows === 0): ?>
  <div class="empty">No licenses found. Try clearing filters or <a href="license-issue.php">issue a license</a>.</div>
<?php else: ?>
  <table class="table">
    <tr>
      <th>ID</th>
      <th>Key</th>
      <th>Status</th>
      <th>Type</th>
      <th>Issued To</th>
      <th>Domain</th>
      <th>Expires</th>
      <th>Activated</th>
      <th>Created</th>
      <th>Updated</th>
      <th>Actions</th>
    </tr>
    <?php $now = time(); while ($r = $res->fetch_assoc()): ?>
      <?php
        $st = (string)$r['status'];
        $cls = in_array($st, ['issued','active','revoked','expired'], true) ? $st : 'issued';
        $expired = (!empty($r['expires_at']) && strtotime($r['expires_at']) < $now);
      ?>
      <tr>
        <td><?= (int)$r['id'] ?></td>
        <td class="key"><?= htmlspecialchars($r['license_key']) ?></td>
        <td><span class="badge <?= $cls ?>"><?= htmlspecialchars($st !== '' ? $st : '(unknown)') ?></span></td>
        <td><?= htmlspecialchars((string)$r['type']) ?></td>
        <td><?= htmlspecialchars((string)$r['issued_to']) ?></td>
        <td><?= htmlspecialchars((string)$r['site_domain']) ?></td>
        <td><?= htmlspecialchars((string)$r['expires_at']) ?></td>
        <td><?= htmlspecialchars((string)$r['activated_at']) ?></td>
        <td class="small"><?= htmlspecialchars((string)$r['created_at']) ?></td>
        <td class="small"><?= htmlspecialchars((string)$r['updated_at']) ?></td>
        <td class="actions">
          <a href="license-edit.php?id=<?= (int)$r['id'] ?>">Edit</a>
          <a href="license-extend.php?id=<?= (int)$r['id'] ?>">Extend</a>
          <?php if ($st === 'active'): ?>
            <a href="license-revoke.php?id=<?= (int)$r['id'] ?>">Revoke</a>
          <?php elseif ($st === 'issued'): ?>
            <a href="license-reactivate.php?id=<?= (int)$r['id'] ?>">Set Active</a>
            <a href="license-revoke.php?id=<?= (int)$r['id'] ?>">Revoke</a>
          <?php elseif ($st === 'revoked'): ?>
            <?php if (!$expired): ?>
              <a href="license-reactivate.php?id=<?= (int)$r['id'] ?>">Reactivate</a>
            <?php endif; ?>
          <?php else: /* expired or unknown */ ?>
            <?php if (!$expired): ?>
              <a href="license-reactivate.php?id=<?= (int)$r['id'] ?>">Reactivate</a>
            <?php else: ?>
              <span class="small" title="Expired licenses can be extended/renewed.">—</span>
            <?php endif; ?>
          <?php endif; ?>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>
<?php endif; ?>

<?php
if (isset($stmt) && $stmt instanceof mysqli_stmt) { $stmt->close(); }
if (!$loadedHeader) { echo "</body></html>"; }
