<?php
// admin/index.php — Admin Home (quick links, stats, recent activity, security snapshot)
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/log.php';
require_admin();

// ---- DB handle
$dbc = null;
if (isset($db) && $db instanceof mysqli)             { $dbc = $db; }
elseif (isset($conn) && $conn instanceof mysqli)     { $dbc = $conn; }
elseif (isset($mysqli) && $mysqli instanceof mysqli) { $dbc = $mysqli; }
elseif (function_exists('get_db'))                   { $dbc = get_db(); }
if (!$dbc instanceof mysqli) { http_response_code(500); exit('Database handle not initialized.'); }

// Ensure audit/login tables so queries below always work
__log_ensure_tables($dbc);

// Helpers
function table_exists(mysqli $dbc, string $name): bool {
    $ok = false;
    if ($stmt = $dbc->prepare("SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?")) {
        $stmt->bind_param('s', $name);
        $stmt->execute(); $stmt->bind_result($one);
        $ok = (bool)$stmt->fetch();
        $stmt->close();
    }
    return $ok;
}
function q1(mysqli $dbc, string $sql, array $bind = [], string $types = '') {
    if (!$bind) {
        if ($res = $dbc->query($sql)) { $row = $res->fetch_row(); return $row ? $row[0] : 0; }
        return 0;
    }
    $stmt = $dbc->prepare($sql);
    if ($types !== '') $stmt->bind_param($types, ...$bind);
    $stmt->execute(); $res = $stmt->get_result();
    $row = $res ? $res->fetch_row() : null;
    $stmt->close();
    return $row ? $row[0] : 0;
}
function rows(mysqli $dbc, string $sql, array $bind = [], string $types = ''): array {
    if (!$bind) {
        $res = $dbc->query($sql); $out = [];
        if ($res) while ($r = $res->fetch_assoc()) $out[] = $r;
        return $out;
    }
    $stmt = $dbc->prepare($sql);
    if ($types !== '') $stmt->bind_param($types, ...$bind);
    $stmt->execute(); $res = $stmt->get_result(); $out = [];
    if ($res) while ($r = $res->fetch_assoc()) $out[] = $r;
    $stmt->close();
    return $out;
}

// ---- Stats: Users
$usersExists  = table_exists($dbc, 'users');
$userTotal    = $usersExists ? (int)q1($dbc, "SELECT COUNT(*) FROM users") : 0;
$userActive   = $usersExists ? (int)q1($dbc, "SELECT COUNT(*) FROM users WHERE active=1") : 0;
$userLocked   = $usersExists ? (int)q1($dbc, "SELECT COUNT(*) FROM users WHERE locked_until IS NOT NULL AND locked_until > NOW()") : 0;

// ---- Stats: Licenses
$licExists    = table_exists($dbc, 'licenses');
$licTotal     = $licExists ? (int)q1($dbc, "SELECT COUNT(*) FROM licenses") : 0;
$licActive    = $licExists ? (int)q1($dbc, "SELECT COUNT(*) FROM licenses WHERE status='active'") : 0;
$licIssued    = $licExists ? (int)q1($dbc, "SELECT COUNT(*) FROM licenses WHERE status='issued'") : 0;
$licRevoked   = $licExists ? (int)q1($dbc, "SELECT COUNT(*) FROM licenses WHERE status='revoked'") : 0;
$licExpired   = $licExists ? (int)q1($dbc, "SELECT COUNT(*) FROM licenses WHERE status='expired'") : 0;

// ---- Security snapshot
$window = defined('LOGIN_RATE_WINDOW_SECONDS') ? max(30, (int)LOGIN_RATE_WINDOW_SECONDS) : 600;
$thrIP  = defined('LOGIN_RATE_MAX_FAILS_PER_IP') ? max(1, (int)LOGIN_RATE_MAX_FAILS_PER_IP) : 15;
$thrPair= defined('LOGIN_RATE_MAX_FAILS_PER_IP_EMAIL') ? max(1, (int)LOGIN_RATE_MAX_FAILS_PER_IP_EMAIL) : 6;

$fail24h = (int)q1($dbc, "SELECT COUNT(*) FROM login_attempts WHERE success=0 AND created_at > NOW() - INTERVAL 1 DAY");
$succ24h = (int)q1($dbc, "SELECT COUNT(*) FROM login_attempts WHERE success=1 AND created_at > NOW() - INTERVAL 1 DAY");

// “blocked now” (approx): IPs over threshold in the current window
$blockedIPs = rows($dbc,
    "SELECT ip, COUNT(*) AS c FROM login_attempts
      WHERE success=0 AND created_at > NOW() - INTERVAL ? SECOND
      GROUP BY ip HAVING c >= ? ORDER BY c DESC LIMIT 5",
    [$window, $thrIP], 'ii');

// Recent activity
$recentAudit = rows($dbc, "SELECT event, actor, ip, details, created_at FROM audit_log ORDER BY id DESC LIMIT 10");
$recentLogin = rows($dbc, "SELECT success, actor, ip, note, created_at FROM login_attempts ORDER BY id DESC LIMIT 10");

// ---- Header loader
$loadedHeader = false;
foreach ([__DIR__.'/admin-header.php', __DIR__.'/header-admin.php', __DIR__.'/header.php', __DIR__.'/../includes/admin-header.php'] as $p) {
  if (is_file($p)) { include $p; $loadedHeader = true; break; }
}
if (!$loadedHeader) {
  echo "<!doctype html><html><head><meta charset='utf-8'><title>Admin</title></head><body>";
}
?>
<h1>Admin Home</h1>

<style>
  :root { --card-bg:#fff; --muted:#666; --bd:#e5e5e5; }
  .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin:12px 0}
  .card{background:var(--card-bg);border:1px solid var(--bd);border-radius:10px;padding:12px}
  .card h3{margin:0 0 6px 0;font-size:1rem}
  .kpi{font-size:1.4rem;font-weight:600}
  .muted{color:var(--muted);font-size:.9rem}
  .btnrow{display:flex;flex-wrap:wrap;gap:.5rem;margin:.5rem 0}
  .btn{padding:.3rem .55rem;border:1px solid #ccc;border-radius:6px;background:#fff;text-decoration:none;color:#333}
  .btn:hover{background:#f7f7f7}
  .two{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  @media (max-width: 900px){ .two{grid-template-columns:1fr} }
  table{border-collapse:collapse;width:100%}
  th,td{border:1px solid #e3e3e3;padding:6px 8px;font-size:.94rem;vertical-align:top}
  th{background:#f7f7f7;text-align:left}
  .ok{background:#e8fff0;border-color:#9bd3af}
  .warn{background:#fff6e5;border-color:#f1c27d}
  .bad{background:#ffecec;border-color:#e3a0a0}
  .mono{font-family:ui-monospace,Menlo,Consolas,monospace}
  .nowrap{white-space:nowrap}
</style>

<div class="grid">
  <div class="card">
    <h3>Users</h3>
    <div class="kpi"><?= (int)$userTotal ?> total</div>
    <div class="muted"><?= (int)$userActive ?> active · <?= (int)$userLocked ?> locked</div>
    <div class="btnrow">
      <a class="btn" href="users.php">Manage Users</a>
      <a class="btn" href="user-add.php">Add User</a>
    </div>
  </div>

  <div class="card">
    <h3>Licenses</h3>
    <div class="kpi"><?= (int)$licTotal ?> total</div>
    <div class="muted">
      active <?= (int)$licActive ?> · issued <?= (int)$licIssued ?> · revoked <?= (int)$licRevoked ?> · expired <?= (int)$licExpired ?>
    </div>
    <div class="btnrow">
      <a class="btn" href="licenses.php">View Licenses</a>
      <a class="btn" href="license-issue.php">Issue</a>
      <a class="btn" href="license-activate.php">Activate</a>
    </div>
  </div>

  <div class="card">
    <h3>Security (<?= (int)$window ?>s window)</h3>
    <div class="kpi"><?= (int)$fail24h ?> failed / <?= (int)$succ24h ?> success (24h)</div>
    <div class="muted">IP threshold: <?= (int)$thrIP ?> · Pair: <?= (int)$thrPair ?></div>
    <?php if (!empty($blockedIPs)): ?>
      <div class="muted" style="margin-top:.4rem;">IPs over threshold now:</div>
      <ul style="margin:.25rem 0 .2rem 1.1rem;padding:0;">
        <?php foreach ($blockedIPs as $b): ?>
          <li class="mono"><?= htmlspecialchars($b['ip'] ?: '(unknown)') ?> — <?= (int)$b['c'] ?> fails</li>
        <?php endforeach; ?>
      </ul>
    <?php else: ?>
      <div class="muted" style="margin-top:.4rem;">No IPs currently over the threshold.</div>
    <?php endif; ?>
  </div>

  <div class="card">
    <h3>Shortcuts</h3>
    <div class="btnrow">
      <a class="btn" href="schema-check.php">Schema Check</a>
      <a class="btn" href="devlog.php">Devlog</a>
      <?php if (is_file(__DIR__ . '/mail-test.php')): ?>
        <a class="btn" href="mail-test.php">Mail Test</a>
      <?php endif; ?>
      <a class="btn" href="backup-now.php">Backup Now</a>
    </div>
    <div class="muted">reCAPTCHA: <?= (defined('RECAPTCHA_ENABLED') && RECAPTCHA_ENABLED) ? 'on' : 'off' ?> · SMTP: <?= (defined('SMTP_ENABLED') && SMTP_ENABLED) ? 'on' : 'off' ?></div>
    <div class="muted">PHP <?= htmlspecialchars(PHP_VERSION) ?> · MySQL <?= htmlspecialchars(@$dbc->server_info ?: 'n/a') ?></div>
  </div>
</div>

<div class="two" style="margin-top:12px;">
  <div class="card">
    <h3>Recent Audit</h3>
    <?php if (!$recentAudit): ?>
      <div class="muted">No audit entries yet.</div>
    <?php else: ?>
      <table>
        <tr><th class="nowrap">When</th><th>Event</th><th>Actor</th><th>IP</th><th>Details</th></tr>
        <?php foreach ($recentAudit as $a): ?>
          <tr>
            <td class="nowrap"><?= htmlspecialchars((string)$a['created_at']) ?></td>
            <td><?= htmlspecialchars((string)$a['event']) ?></td>
            <td><?= htmlspecialchars((string)$a['actor']) ?></td>
            <td class="mono"><?= htmlspecialchars((string)$a['ip']) ?></td>
            <td><?= htmlspecialchars(mb_strimwidth((string)$a['details'], 0, 140, '…')) ?></td>
          </tr>
        <?php endforeach; ?>
      </table>
    <?php endif; ?>
  </div>

  <div class="card">
    <h3>Recent Login Attempts</h3>
    <?php if (!$recentLogin): ?>
      <div class="muted">No login attempts yet.</div>
    <?php else: ?>
      <table>
        <tr><th class="nowrap">When</th><th>Status</th><th>Actor</th><th>IP</th><th>Note</th></tr>
        <?php foreach ($recentLogin as $l): ?>
          <tr>
            <td class="nowrap"><?= htmlspecialchars((string)$l['created_at']) ?></td>
            <td><?= $l['success'] ? '✅ success' : '❌ failed' ?></td>
            <td><?= htmlspecialchars((string)$l['actor']) ?></td>
            <td class="mono"><?= htmlspecialchars((string)$l['ip']) ?></td>
            <td><?= htmlspecialchars((string)$l['note']) ?></td>
          </tr>
        <?php endforeach; ?>
      </table>
    <?php endif; ?>
  </div>
</div>

<?php if (!$loadedHeader) { echo "</body></html>"; } ?>
