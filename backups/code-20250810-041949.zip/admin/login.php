<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/log.php';

if (session_status() !== PHP_SESSION_ACTIVE) session_start();

$nextRaw = $_GET['next'] ?? $_POST['next'] ?? '';
$nextForRedirect = $nextRaw !== '' ? sanitize_admin_path($nextRaw) : '';

$error = '';

// Handle login first (before printing any header)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pin = (string)($_POST['pin'] ?? '');
    $grant_licenses = !empty($_POST['grant_licenses']);
    $grant_users    = !empty($_POST['grant_users']);

    if ($pin !== '' && defined('ADMIN_PASSWORD_HASH') && password_verify($pin, ADMIN_PASSWORD_HASH)) {
        $_SESSION['is_admin'] = true;
        $_SESSION['perms'] = [
            'manage_licenses' => $grant_licenses,
            'manage_users'    => $grant_users,
        ];
        log_login_attempt(true, 'admin login ok', 'admin');
        log_audit('admin_login', 'Admin login successful', 'admin');

        header('Location: ' . ($nextForRedirect !== '' ? $nextForRedirect : 'index.php'));
        exit;
    } else {
        $error = 'Invalid PIN.';
        log_login_attempt(false, 'invalid pin', 'guest');
        log_audit('admin_login_failed', 'Invalid PIN attempt', 'guest');
    }
}

// ---- resilient admin header loader
$loadedHeader = false;
$candidates = [
    __DIR__ . '/admin-header.php',
    __DIR__ . '/header-admin.php',
    __DIR__ . '/header.php',
    __DIR__ . '/../includes/admin-header.php',
];
foreach ($candidates as $p) {
    if (is_file($p)) { include $p; $loadedHeader = true; break; }
}
if (!$loadedHeader) {
    echo "<!doctype html><html><head><meta charset='utf-8'><title>Admin Login</title>
    <style>.adminbar{display:flex;gap:12px;align-items:center;padding:10px;border-bottom:1px solid #ddd;background:#f7f7f7}
    .adminbar a{color:#333;text-decoration:none}.adminbar a:hover{text-decoration:underline}
    body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif}</style>
    </head><body>
    <nav class='adminbar'>
      <a href='index.php'>↩️ Back to Admin Home</a>
      <a href='logout.php'>🚪 Logout</a>
    </nav>";
}
?>
<h1>Admin Login</h1>
<?php if ($error): ?>
  <div style="color:#b00; margin:.5rem 0;"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="post">
  <input type="hidden" name="next" value="<?= htmlspecialchars($nextForRedirect, ENT_QUOTES, 'UTF-8') ?>">
  <label>Admin PIN
    <input type="password" name="pin" autofocus>
  </label>

  <fieldset style="border:1px solid #ccc; padding:.5rem; margin-top:.5rem;">
    <legend>Admin Permissions</legend>
    <label style="display:flex;align-items:center;gap:.5rem;margin-top:.25rem">
      <input type="checkbox" name="grant_licenses" value="1" checked>
      Manage licenses
    </label>
    <label style="display:flex;align-items:center;gap:.5rem;margin-top:.25rem">
      <input type="checkbox" name="grant_users" value="1" checked>
      Manage users
    </label>
  </fieldset>

  <div style="margin-top:.75rem;">
    <button type="submit">Sign in</button>
  </div>
</form>
<?php if (!$loadedHeader) { echo "</body></html>"; } ?>
