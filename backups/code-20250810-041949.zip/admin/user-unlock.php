<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/log.php';
require_once __DIR__ . '/../includes/user-auth.php';

require_admin();

// ---- normalize DB handle
$dbc = null;
if (isset($db) && $db instanceof mysqli)             { $dbc = $db; }
elseif (isset($conn) && $conn instanceof mysqli)     { $dbc = $conn; }
elseif (isset($mysqli) && $mysqli instanceof mysqli) { $dbc = $mysqli; }
elseif (function_exists('get_db'))                   { $dbc = get_db(); }
if (!$dbc instanceof mysqli) { http_response_code(500); exit('Database handle not initialized.'); }

require_license($dbc);
require_perm('manage_users');

// ensure schema
ua_ensure_users($dbc);

// CSRF
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
$csrf = $_SESSION['csrf'];

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) { http_response_code(400); exit('Missing id.'); }

// fetch user
$stmt = $dbc->prepare("SELECT id, name, email, failed_logins, locked_until FROM users WHERE id=?");
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
$u = $res ? $res->fetch_assoc() : null;
$stmt->close();
if (!$u) { http_response_code(404); exit('User not found.'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(400); exit('Bad CSRF token.');
    }
    $now = (new DateTimeImmutable('now'))->format('Y-m-d H:i:s');
    if ($stmt = $dbc->prepare("UPDATE users SET failed_logins=0, locked_until=NULL, updated_at=? WHERE id=?")) {
        $stmt->bind_param('si', $now, $id);
        $stmt->execute();
        $stmt->close();
    }
    log_audit('user_unlocked', "id={$id}; email={$u['email']}", 'admin');
    header('Location: users.php');
    exit;
}

// ---- header loader
$loadedHeader = false;
foreach ([__DIR__.'/admin-header.php', __DIR__.'/header-admin.php', __DIR__.'/header.php', __DIR__.'/../includes/admin-header.php'] as $p) {
  if (is_file($p)) { include $p; $loadedHeader = true; break; }
}
if (!$loadedHeader) {
  echo "<!doctype html><html><head><meta charset='utf-8'><title>Unlock User</title></head><body>";
}
?>
<h1>Unlock User</h1>

<p>This will clear failed login attempts and remove the lock.</p>
<ul>
  <li><strong>Name:</strong> <?= htmlspecialchars($u['name']) ?></li>
  <li><strong>Email:</strong> <?= htmlspecialchars($u['email']) ?></li>
  <li><strong>Failed attempts:</strong> <?= (int)$u['failed_logins'] ?></li>
  <li><strong>Locked until:</strong> <?= htmlspecialchars((string)$u['locked_until']) ?></li>
</ul>

<form method="post" style="margin-top:.5rem;">
  <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
  <button type="submit">Unlock now</button>
  <a href="users.php" style="margin-left:.5rem;">Cancel</a>
</form>

<?php if (!$loadedHeader) { echo "</body></html>"; } ?>
