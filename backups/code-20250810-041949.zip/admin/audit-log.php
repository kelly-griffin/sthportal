<?php
declare(strict_types=1);

/**
 * /admin/audit-log.php
 * Read-only viewer for audit_log and login_attempts with simple pagination,
 * plus a CSRF-protected "clear failures for IP" action.
 */

require_once __DIR__ . '/../includes/bootstrap.php'; // brings in guard + csrf + audit + rate_limit

// ----- auth gate: admin only -----
if (empty($_SESSION['is_admin'])) {
    header('Location: /admin/login.php?next=' . urlencode($_SERVER['REQUEST_URI'] ?? '/admin/audit-log.php'));
    exit;
}

// OPTIONAL: require a specific permission to clear attempts
$canClear = true; // or: !empty($_SESSION['perms']['manage_users'])

// ----- helpers -----
function qint(string $key, int $default = 1, int $min = 1, int $max = 100000): int {
    $v = isset($_GET[$key]) ? (int)$_GET[$key] : $default;
    return max($min, min($max, $v));
}
function h(?string $s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// Pagination
$audPage  = qint('ap', 1);
$attPage  = qint('lp', 1);
$perPage  = 25;
$audOff   = ($audPage - 1) * $perPage;
$attOff   = ($attPage - 1) * $perPage;

// ----- handle clear-failures action -----
$flash = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'clear_ip') {
    if (!$canClear) {
        $flash = ['type' => 'error', 'msg' => 'You do not have permission to clear attempts.'];
    } elseif (!csrf_check()) {
        $flash = ['type' => 'error', 'msg' => 'Invalid request token. Please try again.'];
    } else {
        $ip = trim((string)($_POST['ip'] ?? ''));
        // Basic IPv4/IPv6 sanity check (not bulletproof, just to avoid junk)
        if ($ip === '' || strlen($ip) > 45) {
            $flash = ['type' => 'error', 'msg' => 'Invalid IP address.'];
        } else {
            $sql = "DELETE FROM login_attempts WHERE ip = ?";
            if ($stmt = $db->prepare($sql)) {
                $stmt->bind_param('s', $ip);
                $stmt->execute();
                $affected = $stmt->affected_rows;
                $stmt->close();
                audit($db, 'clear_login_attempts', ['ip' => $ip, 'count' => $affected]);
                $flash = ['type' => 'ok', 'msg' => "Cleared $affected attempt(s) for IP $ip."];
            } else {
                $flash = ['type' => 'error', 'msg' => 'DB error while clearing attempts.'];
            }
        }
    }
}

// ----- query audit_log -----
$totalAud = 0;
if ($stmt = $db->prepare("SELECT COUNT(*) FROM audit_log")) {
    $stmt->execute();
    $stmt->bind_result($totalAud);
    $stmt->fetch();
    $stmt->close();
}

$aud = [];
if ($stmt = $db->prepare("
    SELECT occurred_at, ip, admin_user, action, details
    FROM audit_log
    ORDER BY occurred_at DESC, id DESC
    LIMIT ? OFFSET ?
")) {
    $stmt->bind_param('ii', $perPage, $audOff);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $aud[] = $row;
    }
    $stmt->close();
}

// ----- query login_attempts -----
$totalAtt = 0;
if ($stmt = $db->prepare("SELECT COUNT(*) FROM login_attempts")) {
    $stmt->execute();
    $stmt->bind_result($totalAtt);
    $stmt->fetch();
    $stmt->close();
}

$att = [];
if ($stmt = $db->prepare("
    SELECT attempted_at, ip, username, success
    FROM login_attempts
    ORDER BY attempted_at DESC, id DESC
    LIMIT ? OFFSET ?
")) {
    $stmt->bind_param('ii', $perPage, $attOff);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $att[] = $row;
    }
    $stmt->close();
}

// Simple pager helpers
$audPages = max(1, (int)ceil($totalAud / $perPage));
$attPages = max(1, (int)ceil($totalAtt / $perPage));
function pager(string $key, int $page, int $pages): string {
    $prev = max(1, $page - 1);
    $next = min($pages, $page + 1);
    $qsPrev = http_build_query([$key => $prev]);
    $qsNext = http_build_query([$key => $next]);
    return '<div class="pager">'
        . '<a href="?'.$qsPrev.'">&laquo; Prev</a>'
        . '<span>Page '.(int)$page.' / '.(int)$pages.'</span>'
        . '<a href="?'.$qsNext.'">Next &raquo;</a>'
        . '</div>';
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Audit Log</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; margin: 2rem; }
    h1 { margin: 0 0 1rem; }
    .wrap { display: grid; grid-template-columns: 1fr; gap: 2rem; }
    .card { border: 1px solid #ddd; border-radius: 10px; padding: 1rem; box-shadow: 0 1px 4px rgba(0,0,0,.04); }
    table { width: 100%; border-collapse: collapse; margin-top: .5rem; }
    th, td { padding: .5rem .6rem; border-bottom: 1px solid #eee; font-size: 14px; vertical-align: top; }
    th { text-align: left; background: #fafafa; }
    .muted { color: #666; }
    .ok { color: #0a7f2e; font-weight: 600; }
    .fail { color: #b00020; font-weight: 600; }
    .pager { display: flex; gap: 1rem; align-items: center; margin-top: .5rem; }
    .pager a { text-decoration: none; }
    .flash { padding: .6rem .8rem; border-radius: 8px; margin-bottom: .5rem; }
    .flash.ok { background: #e8f6ee; color: #0a7f2e; border: 1px solid #bfe8cf; }
    .flash.err { background: #fdecea; color: #b00020; border: 1px solid #f8c7c2; }
    form.inline { display: inline; margin: 0; }
    .btn { padding: .35rem .6rem; border: 1px solid #ccc; border-radius: 6px; background: #fff; cursor: pointer; }
    .btn:hover { background: #f7f7f7; }
    .danger { border-color: #b00020; color: #b00020; }
  </style>
</head>
<body>
  <h1>Audit &amp; Login Activity</h1>

  <?php if ($flash): ?>
    <div class="flash <?= $flash['type']==='ok'?'ok':'err' ?>"><?= h($flash['msg']) ?></div>
  <?php endif; ?>

  <div class="wrap">
    <div class="card">
      <h2 style="margin:0;">Audit Log</h2>
      <div class="muted"><?= (int)$totalAud ?> entries</div>
      <?= pager('ap', $audPage, $audPages) ?>
      <table>
        <thead>
          <tr>
            <th>When</th>
            <th>IP</th>
            <th>Admin</th>
            <th>Action</th>
            <th>Details</th>
          </tr>
        </thead>
        <tbody>
        <?php if (!$aud): ?>
          <tr><td colspan="5" class="muted">No audit entries yet.</td></tr>
        <?php else: foreach ($aud as $row): ?>
          <tr>
            <td><?= h($row['occurred_at']) ?></td>
            <td><?= h($row['ip']) ?></td>
            <td><?= h($row['admin_user']) ?></td>
            <td><?= h($row['action']) ?></td>
            <td>
              <?php
              $details = $row['details'];
              if ($details) {
                  // pretty-print small JSON safely
                  $decoded = json_decode($details, true);
                  if (is_array($decoded)) {
                      echo '<pre style="white-space:pre-wrap;margin:0;">' . h(json_encode($decoded, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)) . '</pre>';
                  } else {
                      echo '<span class="muted">[invalid json]</span>';
                  }
              } else {
                  echo '<span class="muted">—</span>';
              }
              ?>
            </td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table>
      <?= pager('ap', $audPage, $audPages) ?>
    </div>

    <div class="card">
      <h2 style="margin:0;">Login Attempts</h2>
      <div class="muted"><?= (int)$totalAtt ?> attempts (last <?= (int)$perPage ?> shown on this page)</div>
      <?= pager('lp', $attPage, $attPages) ?>
      <table>
        <thead>
          <tr>
            <th>When</th>
            <th>IP</th>
            <th>User</th>
            <th>Result</th>
            <th>Tools</th>
          </tr>
        </thead>
        <tbody>
        <?php if (!$att): ?>
          <tr><td colspan="5" class="muted">No attempts recorded.</td></tr>
        <?php else: foreach ($att as $row): ?>
          <tr>
            <td><?= h($row['attempted_at']) ?></td>
            <td><?= h($row['ip']) ?></td>
            <td><?= h($row['username']) ?></td>
            <td><?= $row['success'] ? '<span class="ok">SUCCESS</span>' : '<span class="fail">FAIL</span>' ?></td>
            <td>
              <?php if ($canClear && !empty($row['ip'])): ?>
              <form class="inline" method="post" onsubmit="return confirm('Clear all failed attempts for IP <?= h($row['ip']) ?>?');">
                <input type="hidden" name="action" value="clear_ip">
                <input type="hidden" name="ip" value="<?= h($row['ip']) ?>">
                <?= csrf_input(); ?>
                <button class="btn danger" type="submit">Clear for IP</button>
              </form>
              <?php else: ?>
                <span class="muted">—</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table>
      <?= pager('lp', $attPage, $attPages) ?>
    </div>
  </div>
</body>
</html>
