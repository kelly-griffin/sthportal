<?php
// includes/util-mail.php — send_mail() w/ PHPMailer if available, else mail()
// Lint-friendly (no unreachable-code warnings), supports SMTP + fallback.
require_once __DIR__ . '/config.php';

function send_mail(string $to, string $subject, string $html, string $text = ''): bool
{
    // Build plain-text alt
    $text = $text !== '' ? $text : strip_tags(preg_replace('/<br\s*\/?>/i', "\n", $html));

    // Prepare fallback headers now (used only if we fall back)
    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    if (defined('SMTP_FROM')) {
        $fromName = defined('SMTP_FROM_NAME') ? (string)SMTP_FROM_NAME : 'Portal';
        $headers .= 'From: ' . $fromName . ' <' . (string)SMTP_FROM . ">\r\n";
    }

    $result = false; // final outcome

    // Try PHPMailer over SMTP if enabled and available
    $useSMTP = defined('SMTP_ENABLED') && SMTP_ENABLED;
    $havePHPMailer = class_exists('\PHPMailer\PHPMailer\PHPMailer');

    // Lazy include PHPMailer (no Composer required)
    if ($useSMTP && !$havePHPMailer) {
        $base = __DIR__ . '/vendor/PHPMailer/src';
        if (is_file($base.'/PHPMailer.php') && is_file($base.'/SMTP.php') && is_file($base.'/Exception.php')) {
            require_once $base.'/PHPMailer.php';
            require_once $base.'/SMTP.php';
            require_once $base.'/Exception.php';
            $havePHPMailer = class_exists('\PHPMailer\PHPMailer\PHPMailer');
        }
    }

    if ($useSMTP && $havePHPMailer) {
        try {
            $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
            $mail->isSMTP();
            $mail->Host       = (string)SMTP_HOST;
            $mail->Port       = (int)SMTP_PORT;
            $secure           = (string)SMTP_SECURE;
            if ($secure) { $mail->SMTPSecure = $secure; }
            $mail->SMTPAuth   = true;
            $mail->Username   = (string)SMTP_USER;
            $mail->Password   = (string)SMTP_PASS;

            // Runtime flag so linters won't constant-fold this branch
            $allowSelf = getenv('SMTP_ALLOW_SELF_SIGNED') !== false
                ? (bool)filter_var(getenv('SMTP_ALLOW_SELF_SIGNED'), FILTER_VALIDATE_BOOLEAN)
                : (defined('SMTP_ALLOW_SELF_SIGNED') ? (bool)SMTP_ALLOW_SELF_SIGNED : false);

            if ($allowSelf) {
                $mail->SMTPOptions = array(
                    'ssl' => array(
                        'verify_peer'       => false,
                        'verify_peer_name'  => false,
                        'allow_self_signed' => true
                    )
                );
            }

            $fromEmail = defined('SMTP_FROM') ? (string)SMTP_FROM : 'no-reply@localhost';
            $fromName  = defined('SMTP_FROM_NAME') ? (string)SMTP_FROM_NAME : 'Portal';

            $mail->setFrom($fromEmail, $fromName);
            $mail->addAddress($to);
            $mail->Subject = $subject;
            $mail->isHTML(true);
            $mail->Body    = $html;
            $mail->AltBody = $text;

            $result = $mail->send(); // true on success
        } catch (\Throwable $e) {
            $result = false; // fall back to mail()
        }
    }

    // Fallback to PHP mail() if PHPMailer didn’t send
    if (!$result) {
        $result = @mail($to, $subject, $html, $headers);
    }

    return (bool)$result;
}
