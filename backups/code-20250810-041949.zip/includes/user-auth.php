<?php
// includes/user-auth.php — site-user auth with lockout, rate-limits, captcha helper
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/session.php';  // NEW
require_once __DIR__ . '/log.php';      // db + logger + __log_ip()

secure_session_start();                  // NEW

function ua_db(): mysqli { return __log_db(); }

// ensure schemas (idempotent)
function ua_ensure_users(mysqli $dbc): void {
    $dbc->query("CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(128) NOT NULL,
      email VARCHAR(190) NOT NULL,
      role VARCHAR(32) NOT NULL DEFAULT 'member',
      active TINYINT(1) NOT NULL DEFAULT 1,
      password_hash VARCHAR(255) NULL,
      last_login_at DATETIME NULL,
      failed_logins INT NOT NULL DEFAULT 0,
      locked_until DATETIME NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME NULL,
      UNIQUE KEY uq_users_email (email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
    @ $dbc->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS password_hash VARCHAR(255) NULL");
    @ $dbc->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS last_login_at DATETIME NULL");
    @ $dbc->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS failed_logins INT NOT NULL DEFAULT 0");
    @ $dbc->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS locked_until DATETIME NULL");
    @ $dbc->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS updated_at DATETIME NULL");
}
function ua_ensure_resets(mysqli $dbc): void {
    $dbc->query("CREATE TABLE IF NOT EXISTS user_password_resets (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      token VARCHAR(64) NOT NULL,
      expires_at DATETIME NOT NULL,
      used_at DATETIME NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      ip VARCHAR(64) NULL,
      UNIQUE KEY uq_token (token),
      INDEX idx_user (user_id),
      CONSTRAINT fk_upr_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
    @ $dbc->query("ALTER TABLE user_password_resets MODIFY COLUMN ip VARCHAR(64) NULL");
}

// sanitize next
function ua_sanitize_next(string $path): string {
    $path = preg_replace('/([&?])next=[^&]*/i', '$1', $path);
    if (preg_match('#^/(?!/|\\\\).*#', $path)) return strlen($path) > 512 ? '/index.php' : $path;
    return '/index.php';
}

// session helpers
function user_logged_in(): bool { return !empty($_SESSION['user_id']); }
function current_user_id(): ?int { return !empty($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null; }
function current_user_name(): ?string { return $_SESSION['user_name'] ?? null; }
function require_user(): void {
    if (!user_logged_in()) {
        $next = $_SERVER['REQUEST_URI'] ?? '/';
        header('Location: /login.php?next=' . urlencode($next)); exit;
    }
}

// ----- rate limit helpers (reuse existing window/limits)
function ua_rate_block(mysqli $dbc, string $ip, string $email, int &$retryAfterMin): bool {
    $window = defined('LOGIN_RATE_WINDOW_SECONDS') ? max(30, (int)LOGIN_RATE_WINDOW_SECONDS) : 600;
    $maxIP  = defined('LOGIN_RATE_MAX_FAILS_PER_IP') ? max(1, (int)LOGIN_RATE_MAX_FAILS_PER_IP) : 15;
    $maxPair= defined('LOGIN_RATE_MAX_FAILS_PER_IP_EMAIL') ? max(1, (int)LOGIN_RATE_MAX_FAILS_PER_IP_EMAIL) : 6;

    $cutSql = "NOW() - INTERVAL ? SECOND";
    $ipCount = 0; $pairCount = 0;

    if ($stmt = ua_db()->prepare("SELECT COUNT(*) FROM login_attempts WHERE success=0 AND ip=? AND created_at > $cutSql")) {
        $stmt->bind_param('si', $ip, $window);
        $stmt->execute(); $stmt->bind_result($ipCount); $stmt->fetch(); $stmt->close();
    }
    if ($stmt = ua_db()->prepare("SELECT COUNT(*) FROM login_attempts WHERE success=0 AND ip=? AND actor=? AND created_at > $cutSql")) {
        $stmt->bind_param('ssi', $ip, $email, $window);
        $stmt->execute(); $stmt->bind_result($pairCount); $stmt->fetch(); $stmt->close();
    }

    $blocked = ($ipCount >= $maxIP) || ($pairCount >= $maxPair);

    // retry-after estimate
    $retryAfterMin = 10;
    if ($blocked) {
        $mins = null;
        if ($ipCount >= $maxIP) {
            if ($stmt = ua_db()->prepare("SELECT MIN(created_at) FROM login_attempts WHERE success=0 AND ip=? AND created_at > $cutSql")) {
                $stmt->bind_param('si', $ip, $window);
                $stmt->execute(); $stmt->bind_result($minTs); $stmt->fetch(); $stmt->close();
                if ($minTs) $mins = (int)ceil(($window - (time() - strtotime($minTs))) / 60);
            }
        } elseif ($pairCount >= $maxPair) {
            if ($stmt = ua_db()->prepare("SELECT MIN(created_at) FROM login_attempts WHERE success=0 AND ip=? AND actor=? AND created_at > $cutSql")) {
                $stmt->bind_param('ssi', $ip, $email, $window);
                $stmt->execute(); $stmt->bind_result($minTs); $stmt->fetch(); $stmt->close();
                if ($minTs) $mins = (int)ceil(($window - (time() - strtotime($minTs))) / 60);
            }
        }
        if ($mins !== null && $mins > 0) $retryAfterMin = $mins;
    }
    return $blocked;
}

// When to require CAPTCHA (threshold-based)
function ua_should_captcha(mysqli $dbc, string $ip, ?string $email): bool {
    $window  = defined('LOGIN_RATE_WINDOW_SECONDS') ? max(30, (int)LOGIN_RATE_WINDOW_SECONDS) : 600;
    $ipThr   = defined('LOGIN_CAPTCHA_AFTER_IP') ? max(1, (int)LOGIN_CAPTCHA_AFTER_IP) : 8;
    $pairThr = defined('LOGIN_CAPTCHA_AFTER_IP_EMAIL') ? max(1, (int)LOGIN_CAPTCHA_AFTER_IP_EMAIL) : 3;

    $cutSql = "NOW() - INTERVAL ? SECOND";
    $ipCount = 0; $pairCount = 0;

    if ($stmt = ua_db()->prepare("SELECT COUNT(*) FROM login_attempts WHERE success=0 AND ip=? AND created_at > $cutSql")) {
        $stmt->bind_param('si', $ip, $window);
        $stmt->execute(); $stmt->bind_result($ipCount); $stmt->fetch(); $stmt->close();
    }
    if ($email) {
        if ($stmt = ua_db()->prepare("SELECT COUNT(*) FROM login_attempts WHERE success=0 AND ip=? AND actor=? AND created_at > $cutSql")) {
            $stmt->bind_param('ssi', $ip, $email, $window);
            $stmt->execute(); $stmt->bind_result($pairCount); $stmt->fetch(); $stmt->close();
        }
    }
    return ($ipCount >= $ipThr) || ($email && $pairCount >= $pairThr);
}

// ---- core: login / logout
function user_login(string $email, string $password): array {
    $dbc = ua_db(); ua_ensure_users($dbc); __log_ensure_tables($dbc);

    $email = trim($email);
    $ip = __log_ip();

    // hard rate-limit first
    $retryMin = 0;
    if (ua_rate_block($dbc, $ip, $email, $retryMin)) {
        log_audit('user_login_rate_limited', "ip={$ip}; email={$email}", 'guest');
        return [false, "Too many attempts from your network. Try again in ~{$retryMin} min."];
    }

    if ($email === '' || $password === '') {
        return [false, 'Email and password are required.'];
    }

    // fetch user
    $stmt = $dbc->prepare("SELECT id, name, email, role, active, password_hash, failed_logins, locked_until
                             FROM users WHERE email = ? LIMIT 1");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $res = $stmt->get_result();
    $u = $res ? $res->fetch_assoc() : null;
    $stmt->close();

    if (!$u) {
        log_login_attempt(false, 'unknown email', $email);
        log_audit('user_login_failed', "email={$email}; reason=unknown_email", 'guest');
        return [false, 'Invalid credentials.'];
    }

    if ((int)$u['active'] !== 1) {
        log_login_attempt(false, 'inactive account', $email);
        log_audit('user_login_failed', "email={$email}; reason=inactive", 'guest');
        return [false, 'Account is inactive.'];
    }

    // per-account lockout
    $maxFails = defined('USER_LOCKOUT_MAX_FAILS') ? max(1, (int)USER_LOCKOUT_MAX_FAILS) : 5;
    $lockMins = defined('USER_LOCKOUT_DURATION_MINUTES') ? max(1, (int)USER_LOCKOUT_DURATION_MINUTES) : (24*60);

    if (!empty($u['locked_until']) && strtotime($u['locked_until']) > time()) {
        $mins = (int)ceil((strtotime($u['locked_until']) - time()) / 60);
        return [false, "Account locked. Try again in ~{$mins} min."];
    }

    $ok = (!empty($u['password_hash']) && password_verify($password, $u['password_hash']));
    if (!$ok) {
        $fail = (int)$u['failed_logins'] + 1;
        if ($fail >= $maxFails) {
            $lock = (new DateTimeImmutable('now'))->modify("+{$lockMins} minutes")->format('Y-m-d H:i:s');
            $stmt = $dbc->prepare("UPDATE users SET failed_logins=?, locked_until=? WHERE id=?");
            $stmt->bind_param('isi', $fail, $lock, $u['id']);
        } else {
            $stmt = $dbc->prepare("UPDATE users SET failed_logins=? WHERE id=?");
            $stmt->bind_param('ii', $fail, $u['id']);
        }
        $stmt->execute(); $stmt->close();

        log_login_attempt(false, 'bad password', $email);
        log_audit('user_login_failed', "email={$email}; reason=bad_password; fail={$fail}/{$maxFails}", 'guest');
        return [false, 'Invalid credentials.'];
    }

    // success
    $now = (new DateTimeImmutable('now'))->format('Y-m-d H:i:s');
    $zero = 0; $null = null;
    $stmt = $dbc->prepare("UPDATE users SET last_login_at=?, failed_logins=?, locked_until=?, updated_at=? WHERE id=?");
    $stmt->bind_param('sissi', $now, $zero, $null, $now, $u['id']);
    $stmt->execute(); $stmt->close();

    $_SESSION['user_id']   = (int)$u['id'];
    $_SESSION['user_name'] = (string)$u['name'];
    $_SESSION['user_role'] = (string)$u['role'];

    session_on_auth_success(); // NEW: rotate ID, stamp auth_time

    log_login_attempt(true, 'user login ok', $email);
    log_audit('user_login', "email={$email}", 'user');

    return [true, 'OK'];
}

function user_logout(): void {
    // keep session, just clear user keys
    unset($_SESSION['user_id'], $_SESSION['user_name'], $_SESSION['user_role']);
}

// password reset
function user_begin_password_reset(string $email): ?string {
    $dbc = ua_db(); ua_ensure_users($dbc); ua_ensure_resets($dbc);
    $email = trim($email);
    if ($email === '') return null;

    $stmt = $dbc->prepare("SELECT id FROM users WHERE email=? AND active=1 LIMIT 1");
    $stmt->bind_param('s', $email);
    $stmt->execute(); $res = $stmt->get_result();
    $row = $res ? $res->fetch_assoc() : null; $stmt->close();

    if (!$row) {
        log_audit('user_reset_requested', "email={$email}; found=0", 'guest');
        return bin2hex(random_bytes(16));
    }

    $userId = (int)$row['id'];
    $token = bin2hex(random_bytes(16));
    $exp = (new DateTimeImmutable('now'))->modify('+1 hour')->format('Y-m-d H:i:s');
    $ip = __log_ip();

    if ($stmt = $dbc->prepare("INSERT INTO user_password_resets (user_id, token, expires_at, ip) VALUES (?, ?, ?, ?)")) {
        $stmt->bind_param('isss', $userId, $token, $exp, $ip);
        $stmt->execute(); $stmt->close();
    }

    log_audit('user_reset_requested', "email={$email}; user_id={$userId}", 'guest');
    return $token;
}

function user_reset_password(string $token, string $newPassword): bool {
    $dbc = ua_db(); ua_ensure_users($dbc); ua_ensure_resets($dbc);
    if ($token === '' || $newPassword === '' || strlen($newPassword) < 8) return false;

    $stmt = $dbc->prepare("SELECT upr.id, upr.user_id
                             FROM user_password_resets upr
                            WHERE upr.token=? AND upr.used_at IS NULL AND upr.expires_at > NOW()
                            LIMIT 1");
    $stmt->bind_param('s', $token);
    $stmt->execute(); $res = $stmt->get_result();
    $row = $res ? $res->fetch_assoc() : null; $stmt->close();
    if (!$row) return false;

    $uid = (int)$row['user_id'];
    $hash = password_hash($newPassword, PASSWORD_DEFAULT);
    $now  = (new DateTimeImmutable('now'))->format('Y-m-d H:i:s');

    if ($stmt = $dbc->prepare("UPDATE users SET password_hash=?, failed_logins=?, locked_until=?, updated_at=? WHERE id=?")) {
        $zero = 0; $null = null;
        $stmt->bind_param('sissi', $hash, $zero, $null, $now, $uid);
        $stmt->execute(); $stmt->close();
    }
    if ($stmt = $dbc->prepare("UPDATE user_password_resets SET used_at=? WHERE id=?")) {
        $stmt->bind_param('si', $now, $row['id']);
        $stmt->execute(); $stmt->close();
    }

    log_audit('user_password_reset', "user_id={$uid}", 'user');
    return true;
}
