<?php
// includes/log.php — audit + login attempts logger (self-healing + indexes)
require_once __DIR__ . '/session.php';
secure_session_start();
require_once __DIR__ . '/db.php';

// ---- DB handle
function __log_db(): mysqli {
    static $dbc = null;
    if ($dbc instanceof mysqli) return $dbc;
    if (isset($GLOBALS['db']) && $GLOBALS['db'] instanceof mysqli)            { $dbc = $GLOBALS['db']; }
    elseif (isset($GLOBALS['conn']) && $GLOBALS['conn'] instanceof mysqli)    { $dbc = $GLOBALS['conn']; }
    elseif (isset($GLOBALS['mysqli']) && $GLOBALS['mysqli'] instanceof mysqli){ $dbc = $GLOBALS['mysqli']; }
    elseif (function_exists('get_db'))                                        { $dbc = get_db(); }
    if (!$dbc instanceof mysqli) throw new RuntimeException('Logging DB not initialized');
    return $dbc;
}

function __log_ip(): string {
    foreach (['HTTP_CLIENT_IP','HTTP_X_FORWARDED_FOR','REMOTE_ADDR'] as $k) {
        if (!empty($_SERVER[$k])) {
            $ip = $_SERVER[$k];
            if (strpos($ip, ',') !== false) $ip = trim(explode(',', $ip)[0]);
            if ($ip === '::1') $ip = '127.0.0.1';
            return substr(trim($ip), 0, 63);
        }
    }
    return 'unknown';
}
function __log_mask(string $s): string {
    $len = strlen($s);
    if ($len <= 4) return str_repeat('*', $len);
    return str_repeat('*', max(0, $len - 4)) . substr($s, -4);
}

// ---- ensure tables + columns + indexes
function __log_ensure_tables(mysqli $dbc): void {
    static $done = false;
    if ($done) return;

    try {
        $dbc->query("CREATE TABLE IF NOT EXISTS audit_log (
          id INT AUTO_INCREMENT PRIMARY KEY,
          event VARCHAR(128) NOT NULL,
          details TEXT NULL,
          actor VARCHAR(128) NULL,
          ip VARCHAR(64) NULL,
          created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

        $dbc->query("CREATE TABLE IF NOT EXISTS login_attempts (
          id INT AUTO_INCREMENT PRIMARY KEY,
          actor VARCHAR(128) NULL,
          ip VARCHAR(64) NULL,
          success TINYINT(1) NOT NULL,
          note VARCHAR(255) NULL,
          created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

        // audit_log columns
        $cols = [];
        if ($rs = $dbc->query("SELECT column_name, data_type, IFNULL(character_maximum_length,0) AS len
                                 FROM information_schema.columns
                                WHERE table_schema = DATABASE() AND table_name = 'audit_log'")) {
            while ($r = $rs->fetch_assoc()) $cols[$r['column_name']] = $r;
        }
        $need = [
            'event'      => "ALTER TABLE audit_log ADD COLUMN event VARCHAR(128) NOT NULL DEFAULT ''",
            'details'    => "ALTER TABLE audit_log ADD COLUMN details TEXT NULL",
            'actor'      => "ALTER TABLE audit_log ADD COLUMN actor VARCHAR(128) NULL",
            'ip'         => "ALTER TABLE audit_log ADD COLUMN ip VARCHAR(64) NULL",
            'created_at' => "ALTER TABLE audit_log ADD COLUMN created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP",
        ];
        foreach ($need as $c => $ddl) { if (empty($cols[$c])) @ $dbc->query($ddl); }
        if (!empty($cols['ip']) && ((int)$cols['ip']['len'] < 45 || strtolower($cols['ip']['data_type'])!=='varchar')) {
            @ $dbc->query("ALTER TABLE audit_log MODIFY COLUMN ip VARCHAR(64) NULL");
        }

        // login_attempts columns
        $cols2 = [];
        if ($rs = $dbc->query("SELECT column_name, data_type, IFNULL(character_maximum_length,0) AS len
                                 FROM information_schema.columns
                                WHERE table_schema = DATABASE() AND table_name = 'login_attempts'")) {
            while ($r = $rs->fetch_assoc()) $cols2[$r['column_name']] = $r;
        }
        $need2 = [
            'actor'      => "ALTER TABLE login_attempts ADD COLUMN actor VARCHAR(128) NULL",
            'ip'         => "ALTER TABLE login_attempts ADD COLUMN ip VARCHAR(64) NULL",
            'success'    => "ALTER TABLE login_attempts ADD COLUMN success TINYINT(1) NOT NULL DEFAULT 0",
            'note'       => "ALTER TABLE login_attempts ADD COLUMN note VARCHAR(255) NULL",
            'created_at' => "ALTER TABLE login_attempts ADD COLUMN created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP",
        ];
        foreach ($need2 as $c => $ddl) { if (empty($cols2[$c])) @ $dbc->query($ddl); }
        if (!empty($cols2['ip']) && ((int)$cols2['ip']['len'] < 45 || strtolower($cols2['ip']['data_type'])!=='varchar')) {
            @ $dbc->query("ALTER TABLE login_attempts MODIFY COLUMN ip VARCHAR(64) NULL");
        }
        if (!empty($cols2['note']) && (int)$cols2['note']['len'] < 255) {
            @ $dbc->query("ALTER TABLE login_attempts MODIFY COLUMN note VARCHAR(255) NULL");
        }

        // indexes
        $idx = [];
        if ($rs = $dbc->query("SELECT index_name FROM information_schema.statistics
                                WHERE table_schema = DATABASE() AND table_name = 'login_attempts'")) {
            while ($r = $rs->fetch_row()) $idx[$r[0]] = true;
        }
        if (empty($idx['idx_login_ip_created'])) {
            @ $dbc->query("ALTER TABLE login_attempts ADD INDEX idx_login_ip_created (ip, created_at)");
        }
        if (empty($idx['idx_login_actor_created'])) {
            @ $dbc->query("ALTER TABLE login_attempts ADD INDEX idx_login_actor_created (actor, created_at)");
        }
        if (empty($idx['idx_login_ip_actor_created'])) {
            @ $dbc->query("ALTER TABLE login_attempts ADD INDEX idx_login_ip_actor_created (ip, actor, created_at)");
        }
    } catch (Throwable $e) {
        // never break app due to scaffolding
    }

    $done = true;
}

// ---- public APIs
function log_audit(string $event, string $details = '', ?string $actor = null): void {
    try {
        $dbc = __log_db(); __log_ensure_tables($dbc);
        $ip = __log_ip();
        $actor = $actor ?? (!empty($_SESSION['is_admin']) ? 'admin' : 'guest');
        if ($stmt = $dbc->prepare("INSERT INTO audit_log (event, details, actor, ip) VALUES (?, ?, ?, ?)")) {
            $stmt->bind_param('ssss', $event, $details, $actor, $ip);
            $stmt->execute(); $stmt->close();
        }
    } catch (Throwable $e) {}
}

function log_login_attempt(bool $success, string $note = '', ?string $actor = null): void {
    try {
        $dbc = __log_db(); __log_ensure_tables($dbc);
        $ip = __log_ip();
        $actor = $actor ?? (!empty($_SESSION['is_admin']) ? 'admin' : 'guest');
        $succ = $success ? 1 : 0;
        if ($stmt = $dbc->prepare("INSERT INTO login_attempts (actor, ip, success, note) VALUES (?, ?, ?, ?)")) {
            $stmt->bind_param('ssis', $actor, $ip, $succ, $note);
            $stmt->execute(); $stmt->close();
        }
    } catch (Throwable $e) {}
}

// expose masker
function log_mask(string $value): string { return __log_mask($value); }
