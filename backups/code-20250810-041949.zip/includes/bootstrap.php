<?php
declare(strict_types=1);

// Common bootstrap for every page.
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';          // expects $db = new mysqli(...)
// Normalize DB handle to $db for all pages
if (!isset($db) || !($db instanceof mysqli)) {
    if (isset($mysqli) && $mysqli instanceof mysqli) {
        $db = $mysqli;
    } elseif (isset($conn) && $conn instanceof mysqli) {
        $db = $conn;
    }
}
require_once __DIR__ . '/license.php';     // keep any helpers you already have

// Optional: license guard if you added it
if (file_exists(__DIR__ . '/license_guard.php')) {
    require_once __DIR__ . '/license_guard.php';
}
