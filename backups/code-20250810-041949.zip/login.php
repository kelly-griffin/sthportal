<?php
require_once __DIR__ . '/includes/user-auth.php';
require_once __DIR__ . '/includes/recaptcha.php';

if (session_status() !== PHP_SESSION_ACTIVE) session_start();

$nextRaw = $_GET['next'] ?? $_POST['next'] ?? '/';
$next    = $nextRaw !== '' ? ua_sanitize_next($nextRaw) : '/';

$ip = __log_ip();
$preEmail = isset($_POST['email']) ? (string)$_POST['email'] : '';

$needCaptchaGet = recaptcha_enabled() && ua_should_captcha(ua_db(), $ip, null);

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = (string)($_POST['email'] ?? '');
    $pass  = (string)($_POST['password'] ?? '');

    $needCaptcha = recaptcha_enabled() && ua_should_captcha(ua_db(), $ip, $email);
    if ($needCaptcha) {
        [$okCap, $capErr] = recaptcha_verify_post($_POST['g-recaptcha-response'] ?? '', $ip);
        if (!$okCap) {
            log_login_attempt(false, 'captcha_required', $email);
            $error = 'Please complete the CAPTCHA.';
        }
    }

    if ($error === '') {
        [$ok, $msg] = user_login($email, $pass);
        if ($ok) {
            header('Location: ' . $next);
            exit;
        } else {
            $error = $msg ?: 'Login failed.';
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8"><title>Sign in</title>
  <?php if (recaptcha_enabled()): ?>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
  <?php endif; ?>
</head>
<body>
<h1>Sign in</h1>
<?php if ($error): ?><div style="color:#b00;"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="post">
  <input type="hidden" name="next" value="<?= htmlspecialchars($next, ENT_QUOTES, 'UTF-8') ?>">
  <div><label>Email <input type="email" name="email" value="<?= htmlspecialchars($preEmail) ?>" required autofocus></label></div>
  <div><label>Password <input type="password" name="password" required></label></div>

  <?php
    $showCaptcha = recaptcha_enabled() && ($needCaptchaGet || (!empty($preEmail) && ua_should_captcha(ua_db(), $ip, $preEmail)));
    if ($showCaptcha):
  ?>
    <div style="margin-top:.5rem;">
      <div class="g-recaptcha" data-sitekey="<?= htmlspecialchars((string)RECAPTCHA_SITE_KEY) ?>"></div>
    </div>
  <?php endif; ?>

  <div style="margin-top:.5rem;">
    <button type="submit">Sign in</button>
    <a href="/forgot.php" style="margin-left:.5rem;">Forgot password?</a>
  </div>
</form>
</body>
</html>
