<?php
require_once __DIR__ . '/includes/user-auth.php';
user_logout();
header('Location: /');
exit;
