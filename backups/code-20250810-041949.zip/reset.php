<?php
require_once __DIR__ . '/includes/user-auth.php';

$token = (string)($_GET['token'] ?? $_POST['token'] ?? '');
$ok = null;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new = (string)($_POST['password'] ?? '');
    $confirm = (string)($_POST['confirm'] ?? '');
    if ($new === '' || strlen($new) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif ($new !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $ok = user_reset_password($token, $new);
        if ($ok) {
            header('Location: /login.php');
            exit;
        } else {
            $error = 'Invalid or expired token.';
        }
    }
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Reset password</title></head>
<body>
<h1>Reset password</h1>
<?php if ($error): ?><div style="color:#b00;"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="post">
  <input type="hidden" name="token" value="<?= htmlspecialchars($token, ENT_QUOTES, 'UTF-8') ?>">
  <div><label>New password <input type="password" name="password" required></label></div>
  <div><label>Confirm password <input type="password" name="confirm" required></label></div>
  <div style="margin-top:.5rem;"><button type="submit">Set password</button></div>
</form>
<p><a href="/login.php">Back to sign in</a></p>
</body>
</html>
