<?php
require_once __DIR__ . '/includes/user-auth.php';
require_once __DIR__ . '/includes/recaptcha.php';
require_once __DIR__ . '/includes/util-mail.php';

$sent = false;
$link = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (recaptcha_enabled()) {
        [$okCap, $capErr] = recaptcha_verify_post($_POST['g-recaptcha-response'] ?? '', __log_ip());
        if (!$okCap) $error = 'Please complete the CAPTCHA.';
    }

    if ($error === '') {
        $email = (string)($_POST['email'] ?? '');
        $token = user_begin_password_reset($email);
        $sent = true;

        // Build reset URL (works on localhost too)
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $url    = $token ? $scheme . '://' . $host . '/reset.php?token=' . urlencode($token) : '';

        if ($token) {
            $subject = 'Reset your STH Portal password';
            $html = "<p>You (or someone) requested a password reset.</p>
                     <p><a href=\"$url\">Click here to reset your password</a></p>
                     <p>If you didn't request this, you can ignore this email.</p>";
            $text = "You (or someone) requested a password reset.\n\n".
                    "Open this link to reset: $url\n\n".
                    "If you didn't request this, you can ignore this email.";

            // Fire and forget
            @send_mail($email, $subject, $html, $text);

            // Dev convenience: show link if SMTP is off
            if (!SMTP_ENABLED) $link = $url;
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8"><title>Forgot password</title>
  <?php if (recaptcha_enabled()): ?>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
  <?php endif; ?>
</head>
<body>
<h1>Forgot password</h1>
<?php if (!$sent): ?>
  <?php if ($error): ?><div style="color:#b00;"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <form method="post">
    <div><label>Email <input type="email" name="email" required autofocus></label></div>
    <?php if (recaptcha_enabled()): ?>
      <div style="margin-top:.5rem;">
        <div class="g-recaptcha" data-sitekey="<?= htmlspecialchars((string)RECAPTCHA_SITE_KEY) ?>"></div>
      </div>
    <?php endif; ?>
    <div style="margin-top:.5rem;"><button type="submit">Send reset link</button></div>
  </form>
<?php else: ?>
  <p>If that email exists, a reset link has been sent.</p>
  <?php if ($link): ?>
    <p><strong>Dev link:</strong> <a href="<?= htmlspecialchars($link) ?>"><?= htmlspecialchars($link) ?></a></p>
  <?php endif; ?>
  <p><a href="/login.php">Back to sign in</a></p>
<?php endif; ?>
</body>
</html>
